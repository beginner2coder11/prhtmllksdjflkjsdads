// tasteskill / scenes / features — "Hvad vi gør": stepping statements over a held photograph.
window.Scenes = window.Scenes || {};
window.Scenes['features'] = function (root, opts) {
    return Stage.scene(root, {
        hold: 3,
        build: function (tl, ctx) {
            var sts = ctx.q('.st');
            var sps = ctx.q('.sp');
            var n = sts.length;
            var pairs = [[0, 1], [2, 3], [4, 5]];

            tl.set(sts, { opacity: 0 }, 0);
            tl.set(sts[0], { opacity: 1 }, 0);
            tl.set(sps, { opacity: 0, y: 18 }, 0);

            for (var i = 1; i < n; i++) {
                var at = (i - 0.5) / n;
                tl.set(sts[i - 1], { opacity: 0 }, at);
                tl.to(sts[i], { opacity: 1, duration: 0.035 }, at);
            }
            for (var j = 0; j < pairs.length; j++) {
                var on = (j + 0.5) / (n - 1);
                tl.to(sps[pairs[j][0]], { opacity: 1, y: 0, duration: 0.07 }, on);
                tl.to(sps[pairs[j][1]], { opacity: 1, y: 0, duration: 0.07 }, on);
                if (j > 0) {
                    tl.to(sps[pairs[j - 1][0]], { opacity: 0, duration: 0.05 }, on - 0.02);
                    tl.to(sps[pairs[j - 1][1]], { opacity: 0, duration: 0.05 }, on - 0.02);
                }
            }
            var endAt = 0.93;
            tl.to(sps[pairs[pairs.length - 1][0]], { opacity: 0, duration: 0.04 }, endAt);
            tl.to(sps[pairs[pairs.length - 1][1]], { opacity: 0, duration: 0.04 }, endAt);
        }
    });
};
