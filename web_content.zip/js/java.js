/* =========================================================
   COMPUTER INVENTORY
   OFFLINE APPLICATION
========================================================= */

"use strict";


/* =========================================================
   STORAGE KEYS
========================================================= */

const STORAGE_KEYS = {

    ACCOUNT:
        "computerInventoryAccount_v3",

    INVENTORY:
        "computerInventoryDatabase_v3",

    SESSION:
        "computerInventorySession_v3"

};


/* =========================================================
   DEFAULT ACCOUNT
========================================================= */

const DEFAULT_USERNAME = "admin";

const DEFAULT_PASSWORD = "admin123";


/* =========================================================
   STATUS DEFINITIONS
========================================================= */

const STATUS_LIST = [

    "Active",
    "For Repair",
    "Pulled-out",
    "Missing",
    "Storage",
    "Disposal",
    "Retired"

];


/* =========================================================
   GLOBAL STATE
========================================================= */

let inventory = [];

let currentRecord = null;

let currentEditId = null;

let isAuthenticated = false;


/* =========================================================
   DOM READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializeApplication
);


/* =========================================================
   INITIALIZE
========================================================= */

async function initializeApplication(){

    try{

        loadInventory();

        await initializeAccount();

        bindEvents();

        updateDashboard();

        renderInventoryTable();

        /*
         * IMPORTANT:
         * Security button is explicitly connected here.
         * This fixes the issue where the button appears
         * but does nothing.
         */

        verifyExistingSession();

    }catch(error){

        console.error(error);

        alert(
            "Application initialization failed.\n\n" +
            error.message
        );

    }

}


/* =========================================================
   ACCOUNT INITIALIZATION
========================================================= */

async function initializeAccount(){

    const existing =
        localStorage.getItem(
            STORAGE_KEYS.ACCOUNT
        );

    if(existing){

        return;

    }


    const hash =
        await sha256(DEFAULT_PASSWORD);


    const account = {

        username:
            DEFAULT_USERNAME,

        passwordHash:
            hash,

        createdAt:
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    localStorage.setItem(

        STORAGE_KEYS.ACCOUNT,

        JSON.stringify(account)

    );

}


/* =========================================================
   LOAD ACCOUNT
========================================================= */

function getAccount(){

    try{

        const raw =
            localStorage.getItem(
                STORAGE_KEYS.ACCOUNT
            );

        if(!raw){

            return null;

        }

        return JSON.parse(raw);

    }catch(error){

        console.error(
            "Account read error:",
            error
        );

        return null;

    }

}


/* =========================================================
   HASH PASSWORD
========================================================= */

async function sha256(value){

    if(
        window.crypto &&
        window.crypto.subtle
    ){

        const data =
            new TextEncoder()
            .encode(value);

        const hashBuffer =
            await crypto.subtle.digest(
                "SHA-256",
                data
            );

        const bytes =
            new Uint8Array(hashBuffer);

        return Array.from(bytes)
            .map(
                byte =>
                    byte
                    .toString(16)
                    .padStart(2,"0")
            )
            .join("");

    }


    /*
     * Fallback for unusual offline WebView
     * environments where SubtleCrypto is not
     * exposed.
     */

    return fallbackHash(value);

}


/* =========================================================
   FALLBACK HASH
========================================================= */

function fallbackHash(value){

    /*
     * This fallback is intentionally only used
     * when Web Crypto is unavailable.
     *
     * Modern Android WebView/Chrome normally
     * provides crypto.subtle.
     */

    let h1 = 0x811c9dc5;
    let h2 = 0x01000193;

    for(let i=0;i<value.length;i++){

        const c =
            value.charCodeAt(i);

        h1 ^= c;

        h1 =
            Math.imul(
                h1,
                16777619
            );

        h2 ^= c;

        h2 =
            Math.imul(
                h2,
                2246822519
            );

    }

    return (
        (h1 >>> 0)
        .toString(16)
        .padStart(8,"0")
        +

        (h2 >>> 0)
        .toString(16)
        .padStart(8,"0")
    );

}


/* =========================================================
   BIND ALL EVENTS
========================================================= */

function bindEvents(){

    /* LOGIN */

    document
        .getElementById("loginForm")
        .addEventListener(
            "submit",
            handleLogin
        );


    /* LOGOUT */

    document
        .getElementById("logoutButton")
        .addEventListener(
            "click",
            handleLogout
        );


    /*
     * SECURITY BUTTON
     * Explicit event binding.
     */

    document
        .getElementById("securityButton")
        .addEventListener(
            "click",
            openSecurityModal
        );


    document
        .getElementById("closeSecurityButton")
        .addEventListener(
            "click",
            closeSecurityModal
        );


    document
        .getElementById("cancelSecurityButton")
        .addEventListener(
            "click",
            closeSecurityModal
        );


    document
        .getElementById("saveSecurityButton")
        .addEventListener(
            "click",
            changeCredentials
        );


    document
        .getElementById("newPassword")
        .addEventListener(
            "input",
            updatePasswordStrength
        );


    document
        .getElementById("confirmPassword")
        .addEventListener(
            "input",
            updatePasswordStrength
        );


    /*
     * Prevent accidental closing if the user
     * clicks inside modal card.
     */

    document
        .getElementById("securityModal")
        .addEventListener(
            "click",
            function(event){

                if(
                    event.target ===
                    document.getElementById(
                        "securityModal"
                    )
                ){

                    closeSecurityModal();

                }

            }
        );


    /* NAVIGATION + QUICK ACTIONS */
    document.querySelectorAll("[data-nav]").forEach(function(link){
        link.addEventListener("click", function(){
            setActiveNavigation(link.dataset.nav);
        });
    });

    document.getElementById("navSecurityButton").addEventListener("click", openSecurityModal);
    document.getElementById("quickAddButton").addEventListener("click", function(){
        resetInventoryForm();
        document.getElementById("inventoryFormSection").scrollIntoView({behavior:"smooth",block:"start"});
        setActiveNavigation("inventoryFormSection");
        document.getElementById("fControlNumber").focus({preventScroll:true});
    });
    document.getElementById("quickFindButton").addEventListener("click", function(){
        document.getElementById("searchSection").scrollIntoView({behavior:"smooth",block:"start"});
        setActiveNavigation("searchSection");
        document.getElementById("controlNumber").focus({preventScroll:true});
    });

    /* SEARCH */

    document
        .getElementById("searchForm")
        .addEventListener(
            "submit",
            handleSearch
        );


    document
        .getElementById("clearSearchButton")
        .addEventListener(
            "click",
            clearSearch
        );


    /* INVENTORY FORM */

    document
        .getElementById("inventoryForm")
        .addEventListener(
            "submit",
            saveInventory
        );


    document
        .getElementById("resetFormButton")
        .addEventListener(
            "click",
            resetInventoryForm
        );


    /* EDIT */

    document
        .getElementById("editButton")
        .addEventListener(
            "click",
            editCurrentRecord
        );


    /* DELETE */

    document
        .getElementById("deleteButton")
        .addEventListener(
            "click",
            deleteCurrentRecord
        );


    /* PRINT */

    document
        .getElementById("printDetailsButton")
        .addEventListener(
            "click",
            printDetails
        );


    /* QR */

    document
        .getElementById("downloadQRButton")
        .addEventListener(
            "click",
            downloadQR
        );


    document
        .getElementById("printQRButton")
        .addEventListener(
            "click",
            printQR
        );


    /* BACKUP */

    document
        .getElementById("exportJSONButton")
        .addEventListener(
            "click",
            exportJSON
        );


    document
        .getElementById("importJSONButton")
        .addEventListener(
            "click",
            function(){

                document
                    .getElementById(
                        "importFile"
                    )
                    .click();

            }
        );


    document
        .getElementById("importFile")
        .addEventListener(
            "change",
            importJSON
        );


    document
        .getElementById("exportCSVButton")
        .addEventListener(
            "click",
            exportCSV
        );


    document
        .getElementById("clearDatabaseButton")
        .addEventListener(
            "click",
            clearDatabase
        );


}


/* =========================================================
   NAVIGATION STATE
========================================================= */
function setActiveNavigation(sectionId){
    document.querySelectorAll("[data-nav]").forEach(function(link){
        const active = link.dataset.nav === sectionId;
        link.classList.toggle("active", active);
        if(active) link.setAttribute("aria-current", "location");
        else link.removeAttribute("aria-current");
    });
}

/* =========================================================
   LOGIN
========================================================= */

async function handleLogin(event){

    event.preventDefault();

    const username =
        document
        .getElementById("username")
        .value
        .trim();

    const password =
        document
        .getElementById("password")
        .value;


    const status =
        document
        .getElementById("loginStatus");


    if(!username || !password){

        showStatus(
            status,
            "Please enter username and password.",
            "error"
        );

        return;

    }


    const account =
        getAccount();


    if(!account){

        showStatus(
            status,
            "Account configuration is missing.",
            "error"
        );

        return;

    }


    const passwordHash =
        await sha256(password);


    if(
        username !== account.username ||
        passwordHash !== account.passwordHash
    ){

        showStatus(
            status,
            "Invalid username or password.",
            "error"
        );

        document
            .getElementById("password")
            .value = "";

        return;

    }


    isAuthenticated = true;

    sessionStorage.setItem(
        STORAGE_KEYS.SESSION,
        "authenticated"
    );


    showStatus(
        status,
        "Login successful.",
        "success"
    );


    setTimeout(
        showApplication,
        250
    );

}


/* =========================================================
   SESSION
========================================================= */

function verifyExistingSession(){

    const session =
        sessionStorage.getItem(
            STORAGE_KEYS.SESSION
        );


    if(
        session === "authenticated"
    ){

        isAuthenticated = true;

        showApplication();

    }

}


/* =========================================================
   SHOW APPLICATION
========================================================= */

function showApplication(){

    if(!isAuthenticated){

        return;

    }


    document
        .getElementById("loginScreen")
        .classList.add("hidden");


    document
        .getElementById("appScreen")
        .classList.remove("hidden");


    updateDashboard();

    renderInventoryTable();

}


/* =========================================================
   LOGOUT
========================================================= */

function handleLogout(){

    isAuthenticated = false;

    currentRecord = null;

    sessionStorage.removeItem(
        STORAGE_KEYS.SESSION
    );


    closeSecurityModal();

    document
        .getElementById("appScreen")
        .classList.add("hidden");


    document
        .getElementById("loginScreen")
        .classList.remove("hidden");


    document
        .getElementById("username")
        .value = "";


    document
        .getElementById("password")
        .value = "";


    document
        .getElementById("loginStatus")
        .textContent = "";

}


/* =========================================================
   SECURITY MODAL
========================================================= */

function openSecurityModal(){

    if(!isAuthenticated){

        return;

    }


    const account =
        getAccount();


    if(!account){

        alert(
            "Security account is not available."
        );

        return;

    }


    /*
     * Show current username as a starting value.
     */

    document
        .getElementById("newUsername")
        .value =
            account.username;


    document
        .getElementById("currentPassword")
        .value = "";


    document
        .getElementById("newPassword")
        .value = "";


    document
        .getElementById("confirmPassword")
        .value = "";


    document
        .getElementById("passwordStrength")
        .textContent = "";


    document
        .getElementById("securityStatus")
        .textContent = "";


    const modal =
        document
        .getElementById("securityModal");


    modal
        .classList
        .remove("hidden");


    modal
        .setAttribute(
            "aria-hidden",
            "false"
        );


    setTimeout(
        function(){

            document
                .getElementById(
                    "currentPassword"
                )
                .focus();

        },
        50
    );

}


/* =========================================================
   CLOSE SECURITY MODAL
========================================================= */

function closeSecurityModal(){

    const modal =
        document
        .getElementById("securityModal");


    modal
        .classList
        .add("hidden");


    modal
        .setAttribute(
            "aria-hidden",
            "true"
        );

}


/* =========================================================
   PASSWORD STRENGTH
========================================================= */

function updatePasswordStrength(){

    const password =
        document
        .getElementById("newPassword")
        .value;


    const confirm =
        document
        .getElementById("confirmPassword")
        .value;


    const output =
        document
        .getElementById("passwordStrength");


    if(!password){

        output.textContent = "";

        return;

    }


    const lengthOK =
        password.length >= 8;

    const letterOK =
        /[A-Za-z]/.test(password);

    const numberOK =
        /\d/.test(password);

    const upperOK =
        /[A-Z]/.test(password);

    const specialOK =
        /[^A-Za-z0-9]/.test(password);


    let score = 0;

    if(lengthOK) score++;

    if(letterOK) score++;

    if(numberOK) score++;

    if(upperOK) score++;

    if(specialOK) score++;


    let strength =
        "Weak";


    if(score >= 4){

        strength = "Strong";

    }else if(score >= 3){

        strength = "Good";

    }


    let message =
        "Password strength: " +
        strength;


    if(!lengthOK){

        message +=
            " • minimum 8 characters";

    }

    if(!letterOK){

        message +=
            " • add a letter";

    }

    if(!numberOK){

        message +=
            " • add a number";

    }

    if(
        confirm &&
        password !== confirm
    ){

        message +=
            " • passwords do not match";

    }


    output.textContent =
        message;

}


/* =========================================================
   CHANGE CREDENTIALS
========================================================= */

async function changeCredentials(){

    if(!isAuthenticated){

        return;

    }


    const currentPassword =
        document
        .getElementById("currentPassword")
        .value;


    const newUsername =
        document
        .getElementById("newUsername")
        .value
        .trim();


    const newPassword =
        document
        .getElementById("newPassword")
        .value;


    const confirmPassword =
        document
        .getElementById("confirmPassword")
        .value;


    const status =
        document
        .getElementById("securityStatus");


    if(!currentPassword){

        showStatus(
            status,
            "Enter your current password.",
            "error"
        );

        return;

    }


    /*
     * Username validation
     */

    if(
        !/^[A-Za-z0-9._-]{4,30}$/
            .test(newUsername)
    ){

        showStatus(
            status,
            "Username must contain 4–30 characters and only letters, numbers, dot, underscore or hyphen.",
            "error"
        );

        return;

    }


    /*
     * Password validation
     */

    if(newPassword.length < 8){

        showStatus(
            status,
            "New password must contain at least 8 characters.",
            "error"
        );

        return;

    }


    if(!/[A-Za-z]/.test(newPassword)){

        showStatus(
            status,
            "New password must contain at least one letter.",
            "error"
        );

        return;

    }


    if(!/\d/.test(newPassword)){

        showStatus(
            status,
            "New password must contain at least one number.",
            "error"
        );

        return;

    }


    if(newPassword !== confirmPassword){

        showStatus(
            status,
            "New password and confirmation do not match.",
            "error"
        );

        return;

    }


    const account =
        getAccount();


    if(!account){

        showStatus(
            status,
            "Account information could not be loaded.",
            "error"
        );

        return;

    }


    /*
     * VERIFY CURRENT PASSWORD
     */

    const currentHash =
        await sha256(
            currentPassword
        );


    if(
        currentHash !==
        account.passwordHash
    ){

        showStatus(
            status,
            "Current password is incorrect. Credentials were NOT changed.",
            "error"
        );

        return;

    }


    /*
     * Prevent using the same password.
     */

    const newHash =
        await sha256(
            newPassword
        );


    if(
        newHash ===
        account.passwordHash
    ){

        showStatus(
            status,
            "New password must be different from the current password.",
            "error"
        );

        return;

    }


    /*
     * Save account.
     */

    const updatedAccount = {

        username:
            newUsername,

        passwordHash:
            newHash,

        createdAt:
            account.createdAt ||
            new Date().toISOString(),

        updatedAt:
            new Date().toISOString()

    };


    try{

        localStorage.setItem(

            STORAGE_KEYS.ACCOUNT,

            JSON.stringify(
                updatedAccount
            )

        );


        /*
         * Verify that the data was actually
         * written to localStorage.
         */

        const verification =
            getAccount();


        if(
            !verification ||
            verification.username !==
                newUsername ||
            verification.passwordHash !==
                newHash
        ){

            throw new Error(
                "Credential storage verification failed."
            );

        }


        showStatus(
            status,
            "Credentials changed successfully. Your new username and password are now active.",
            "success"
        );


        /*
         * Clear sensitive fields.
         */

        document
            .getElementById(
                "currentPassword"
            )
            .value = "";


        document
            .getElementById(
                "newPassword"
            )
            .value = "";


        document
            .getElementById(
                "confirmPassword"
            )
            .value = "";


        /*
         * Force re-authentication.
         */

        setTimeout(
            function(){

                closeSecurityModal();

                handleLogout();

                alert(
                    "Security credentials were updated successfully.\n\n" +
                    "Please sign in again using your new username and password."
                );

            },
            1200
        );


    }catch(error){

        console.error(error);

        showStatus(
            status,
            "Unable to save credentials: " +
            error.message,
            "error"
        );

    }

}


/* =========================================================
   INVENTORY STORAGE
========================================================= */

function loadInventory(){

    try{

        const raw =
            localStorage.getItem(
                STORAGE_KEYS.INVENTORY
            );


        if(!raw){

            inventory = [];

            return;

        }


        const parsed =
            JSON.parse(raw);


        if(!Array.isArray(parsed)){

            throw new Error(
                "Inventory database is not an array."
            );

        }


        inventory =
            parsed.map(
                normalizeRecord
            );


    }catch(error){

        console.error(error);

        inventory = [];

    }

}


/* =========================================================
   SAVE INVENTORY STORAGE
========================================================= */

function persistInventory(){

    localStorage.setItem(

        STORAGE_KEYS.INVENTORY,

        JSON.stringify(inventory)

    );

}


/* =========================================================
   NORMALIZE RECORD
========================================================= */

function normalizeRecord(record){

    return {

        id:
            record.id ||
            generateId(),

        controlNumber:
            clean(record.controlNumber),

        custodian:
            clean(record.custodian),

        department:
            clean(record.department),

        itemType:
            clean(record.itemType),

        description:
            clean(record.description),

        brand:
            clean(record.brand),

        model:
            clean(record.model),

        serialNumber:
            clean(record.serialNumber),

        purchaseDate:
            clean(record.purchaseDate),

        location:
            clean(record.location),

        status:
            STATUS_LIST.includes(
                record.status
            )
                ? record.status
                : "Active",

        problemComplaint:
            clean(record.problemComplaint),

        datePullout:
            clean(record.datePullout),

        dateReturn:
            clean(record.dateReturn),

        placeAT:
            clean(record.placeAT),

        windows:
            clean(record.windows),

        security:
            clean(record.security),

        remarks:
            clean(record.remarks),

        createdAt:
            record.createdAt ||
            new Date().toISOString(),

        updatedAt:
            record.updatedAt ||
            new Date().toISOString()

    };

}


/* =========================================================
   CLEAN VALUE
========================================================= */

function clean(value){

    if(
        value === null ||
        value === undefined
    ){

        return "";

    }

    return String(value).trim();

}


/* =========================================================
   GENERATE ID
========================================================= */

function generateId(){

    return (

        Date.now()
        .toString(36)

        +

        Math.random()
        .toString(36)
        .substring(2,10)

    );

}


/* =========================================================
   SAVE INVENTORY
========================================================= */

function saveInventory(event){

    event.preventDefault();


    if(!isAuthenticated){

        return;

    }


    const formStatus =
        document
        .getElementById("formStatus");


    const record =
        normalizeRecord({

            id:
                document
                .getElementById(
                    "recordId"
                )
                .value
                ||
                generateId(),

            controlNumber:
                document
                .getElementById(
                    "fControlNumber"
                )
                .value,

            custodian:
                document
                .getElementById(
                    "fCustodian"
                )
                .value,

            department:
                document
                .getElementById(
                    "fDepartment"
                )
                .value,

            itemType:
                document
                .getElementById(
                    "fItemType"
                )
                .value,

            description:
                document
                .getElementById(
                    "fDescription"
                )
                .value,

            brand:
                document
                .getElementById(
                    "fBrand"
                )
                .value,

            model:
                document
                .getElementById(
                    "fModel"
                )
                .value,

            serialNumber:
                document
                .getElementById(
                    "fSerialNumber"
                )
                .value,

            purchaseDate:
                document
                .getElementById(
                    "fPurchaseDate"
                )
                .value,

            location:
                document
                .getElementById(
                    "fLocation"
                )
                .value,

            status:
                document
                .getElementById(
                    "fStatus"
                )
                .value,

            problemComplaint:
                document
                .getElementById(
                    "fProblemComplaint"
                )
                .value,

            datePullout:
                document
                .getElementById(
                    "fDatePullout"
                )
                .value,

            dateReturn:
                document
                .getElementById(
                    "fDateReturn"
                )
                .value,

            placeAT:
                document
                .getElementById(
                    "fPlaceAT"
                )
                .value,

            windows:
                document
                .getElementById(
                    "fWindows"
                )
                .value,

            security:
                document
                .getElementById(
                    "fSecurity"
                )
                .value,

            remarks:
                document
                .getElementById(
                    "fRemarks"
                )
                .value

        });


    /*
     * REQUIRED FIELD VERIFICATION
     */

    if(
        !record.controlNumber ||
        !record.custodian ||
        !record.department ||
        !record.itemType ||
        !record.description ||
        !record.location ||
        !record.status
    ){

        showStatus(
            formStatus,
            "Please complete all required fields.",
            "error"
        );

        return;

    }


    /*
     * CONTROL NUMBER DUPLICATE CHECK
     */

    const duplicateControl =
        inventory.find(
            item =>
                item.controlNumber
                .toLowerCase() ===
                record.controlNumber
                .toLowerCase()
                &&
                item.id !== record.id
        );


    if(duplicateControl){

        showStatus(
            formStatus,
            "Control Number already exists.",
            "error"
        );

        return;

    }


    /*
     * SERIAL NUMBER DUPLICATE CHECK
     */

    if(record.serialNumber){

        const duplicateSerial =
            inventory.find(
                item =>
                    item.serialNumber
                    &&
                    item.serialNumber
                    .toLowerCase() ===
                    record.serialNumber
                    .toLowerCase()
                    &&
                    item.id !== record.id
            );


        if(duplicateSerial){

            showStatus(
                formStatus,
                "Serial Number already exists.",
                "error"
            );

            return;

        }

    }


    /*
     * DATE VALIDATION
     */

    if(
        record.dateReturn &&
        record.datePullout &&
        record.dateReturn <
        record.datePullout
    ){

        showStatus(
            formStatus,
            "Date Return cannot be earlier than Date Pull-out.",
            "error"
        );

        return;

    }


    /*
     * SAVE
     */

    const existingIndex =
        inventory.findIndex(
            item =>
                item.id === record.id
        );


    record.updatedAt =
        new Date().toISOString();


    if(existingIndex >= 0){

        inventory[
            existingIndex
        ] = record;

    }else{

        record.createdAt =
            new Date().toISOString();

        inventory.push(record);

    }


    persistInventory();

    updateDashboard();

    renderInventoryTable();

    displayRecord(record);

    showStatus(
        formStatus,
        existingIndex >= 0
            ? "Computer record updated successfully."
            : "Computer record saved successfully.",
        "success"
    );


    setTimeout(
        resetInventoryForm,
        900
    );

}


/* =========================================================
   RESET FORM
========================================================= */

function resetInventoryForm(){

    document
        .getElementById(
            "inventoryForm"
        )
        .reset();


    document
        .getElementById(
            "recordId"
        )
        .value = "";


    document
        .getElementById(
            "formTitle"
        )
        .textContent =
            "➕ Add Computer";


    currentEditId = null;

}


/* =========================================================
   SEARCH
========================================================= */

function handleSearch(event){

    event.preventDefault();


    const query =
        document
        .getElementById(
            "controlNumber"
        )
        .value
        .trim()
        .toLowerCase();


    const status =
        document
        .getElementById(
            "searchStatus"
        );


    if(!query){

        showStatus(
            status,
            "Enter a Control Number or Serial Number.",
            "warning"
        );

        return;

    }


    const record =
        inventory.find(
            item =>
                item.controlNumber
                .toLowerCase() === query
                ||
                (
                    item.serialNumber
                    &&
                    item.serialNumber
                    .toLowerCase() === query
                )
        );


    if(!record){

        document
            .getElementById(
                "inventoryResult"
            )
            .classList
            .add("hidden");


        showStatus(
            status,
            "No matching computer was found.",
            "error"
        );

        currentRecord = null;

        return;

    }


    currentRecord = record;

    displayRecord(record);

    showStatus(
        status,
        "Computer found and verified.",
        "success"
    );

}


/* =========================================================
   CLEAR SEARCH
========================================================= */

function clearSearch(){

    document
        .getElementById(
            "controlNumber"
        )
        .value = "";


    document
        .getElementById(
            "searchStatus"
        )
        .textContent = "";


    document
        .getElementById(
            "inventoryResult"
        )
        .classList
        .add("hidden");


    currentRecord = null;

}


/* =========================================================
   DISPLAY RECORD
========================================================= */

function displayRecord(record){

    currentRecord = record;


    const fields = {

        displayControlNumber:
            record.controlNumber,

        dCustodian:
            record.custodian,

        dDepartment:
            record.department,

        dItemType:
            record.itemType,

        dDescription:
            record.description,

        dBrand:
            record.brand,

        dModel:
            record.model,

        dSerialNumber:
            record.serialNumber,

        dPurchaseDate:
            record.purchaseDate,

        dLocation:
            record.location,

        dStatusDetail:
            record.status,

        dProblemComplaint:
            record.problemComplaint,

        dDatePullout:
            record.datePullout,

        dDateReturn:
            record.dateReturn,

        dPlaceAT:
            record.placeAT,

        dRemarks:
            record.remarks,

        dWindows:
            record.windows,

        dSecurity:
            record.security,

        qrControlNumber:
            record.controlNumber

    };


    Object.keys(fields)
        .forEach(
            id => {

                const element =
                    document
                    .getElementById(id);


                if(element){

                    element.textContent =
                        fields[id] || "-";

                }

            }
        );


    const badge =
        document
        .getElementById(
            "displayStatus"
        );


    badge.textContent =
        record.status;


    const result =
        document
        .getElementById(
            "inventoryResult"
        );


    result.classList
        .remove("hidden");


    generateLocalQR(
        record.controlNumber
    );

}


/* =========================================================
   EDIT CURRENT RECORD
========================================================= */

function editCurrentRecord(){

    if(!currentRecord){

        return;

    }


    const record =
        currentRecord;


    document
        .getElementById(
            "recordId"
        )
        .value =
            record.id;


    document
        .getElementById(
            "fControlNumber"
        )
        .value =
            record.controlNumber;


    document
        .getElementById(
            "fCustodian"
        )
        .value =
            record.custodian;


    document
        .getElementById(
            "fDepartment"
        )
        .value =
            record.department;


    document
        .getElementById(
            "fItemType"
        )
        .value =
            record.itemType;


    document
        .getElementById(
            "fDescription"
        )
        .value =
            record.description;


    document
        .getElementById(
            "fBrand"
        )
        .value =
            record.brand;


    document
        .getElementById(
            "fModel"
        )
        .value =
            record.model;


    document
        .getElementById(
            "fSerialNumber"
        )
        .value =
            record.serialNumber;


    document
        .getElementById(
            "fPurchaseDate"
        )
        .value =
            record.purchaseDate;


    document
        .getElementById(
            "fLocation"
        )
        .value =
            record.location;


    document
        .getElementById(
            "fStatus"
        )
        .value =
            record.status;


    document
        .getElementById(
            "fProblemComplaint"
        )
        .value =
            record.problemComplaint;


    document
        .getElementById(
            "fDatePullout"
        )
        .value =
            record.datePullout;


    document
        .getElementById(
            "fDateReturn"
        )
        .value =
            record.dateReturn;


    document
        .getElementById(
            "fPlaceAT"
        )
        .value =
            record.placeAT;


    document
        .getElementById(
            "fWindows"
        )
        .value =
            record.windows;


    document
        .getElementById(
            "fSecurity"
        )
        .value =
            record.security;


    document
        .getElementById(
            "fRemarks"
        )
        .value =
            record.remarks;


    document
        .getElementById(
            "formTitle"
        )
        .textContent =
            "✏️ Edit Computer";


    currentEditId =
        record.id;


    document
        .getElementById(
            "inventoryFormSection"
        )
        .scrollIntoView({
            behavior:"smooth"
        });

}


/* =========================================================
   DELETE
========================================================= */

function deleteCurrentRecord(){

    if(!currentRecord){

        return;

    }


    const confirmed =
        confirm(
            "Delete computer record:\n\n" +
            currentRecord.controlNumber +
            "\n\nThis action cannot be undone."
        );


    if(!confirmed){

        return;

    }


    inventory =
        inventory.filter(
            item =>
                item.id !==
                currentRecord.id
        );


    persistInventory();

    updateDashboard();

    renderInventoryTable();

    clearSearch();

    resetInventoryForm();

    currentRecord = null;

}


/* =========================================================
   DASHBOARD
========================================================= */

function updateDashboard(){

    const total =
        inventory.length;


    document
        .getElementById(
            "totalRecords"
        )
        .textContent =
            total;


    STATUS_LIST.forEach(
        status => {

            const count =
                inventory.filter(
                    item =>
                        item.status === status
                ).length;


            const percentage =
                total > 0
                    ? (
                        count /
                        total *
                        100
                    )
                    : 0;


            const id =
                statusToId(status);


            const countElement =
                document.getElementById(
                    id + "Count"
                );


            if(countElement){

                countElement.textContent =
                    count;

            }


            const percentageElement =
                document.getElementById(
                    id + "Percentage"
                );


            if(percentageElement){

                percentageElement.textContent =
                    formatPercentage(
                        percentage
                    );

            }


            const progress =
                document.getElementById(
                    id + "Progress"
                );


            if(progress){

                progress.style.width =
                    percentage + "%";

            }

        }
    );


    /*
     * Existing primary dashboard counters
     */

    setText(
        "activeRecords",
        getStatusCount("Active")
    );

    setText(
        "repairRecords",
        getStatusCount("For Repair")
    );

    setText(
        "pulledRecords",
        getStatusCount("Pulled-out")
    );


    setText(
        "activePercentage",
        formatPercentage(
            getStatusPercentage(
                "Active"
            )
        )
    );


    setText(
        "repairPercentage",
        formatPercentage(
            getStatusPercentage(
                "For Repair"
            )
        )
    );


    setText(
        "pulledPercentage",
        formatPercentage(
            getStatusPercentage(
                "Pulled-out"
            )
        )
    );


    renderStatusDashboard();

}


/* =========================================================
   STATUS DASHBOARD
========================================================= */

function renderStatusDashboard(){

    const container =
        document
        .getElementById(
            "statusDashboard"
        );


    const total =
        inventory.length;


    container.innerHTML = "";


    STATUS_LIST.forEach(
        status => {

            const count =
                getStatusCount(status);


            const percentage =
                total > 0
                    ? count /
                      total *
                      100
                    : 0;


            const card =
                document
                .createElement("div");


            card.className =
                "status-card";


            card.innerHTML = `

                <div class="status-name">
                    ${escapeHTML(status)}
                </div>

                <div class="status-count">
                    ${count}
                </div>

                <div class="status-percent">
                    ${formatPercentage(percentage)}
                </div>

                <div class="progress">
                    <div
                        class="progress-bar"
                        style="width:${percentage}%"
                    ></div>
                </div>

            `;


            container.appendChild(card);

        }
    );

}


/* =========================================================
   STATUS HELPERS
========================================================= */

function getStatusCount(status){

    return inventory.filter(
        item =>
            item.status === status
    ).length;

}


function getStatusPercentage(status){

    const total =
        inventory.length;


    if(!total){

        return 0;

    }


    return (
        getStatusCount(status)
        /
        total
        *
        100
    );

}


function statusToId(status){

    return status
        .toLowerCase()
        .replace(/[^a-z0-9]+/g,"_")
        .replace(/^_|_$/g,"");

}


function formatPercentage(value){

    return (
        Number(value)
        .toFixed(1)
        +
        "%"
    );

}


/* =========================================================
   TABLE
========================================================= */

function renderInventoryTable(){

    const tbody =
        document
        .getElementById(
            "inventoryTableBody"
        );


    tbody.innerHTML = "";


    if(!inventory.length){

        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td
                colspan="10"
                style="
                    text-align:center;
                    color:#64748b;
                    padding:30px;
                "
            >
                No inventory records.
            </td>

        `;


        tbody.appendChild(row);

        return;

    }


    inventory.forEach(
        record => {

            const row =
                document.createElement("tr");


            row.innerHTML = `

                <td>
                    <strong>
                        ${escapeHTML(
                            record.controlNumber
                        )}
                    </strong>
                </td>

                <td>
                    ${escapeHTML(
                        record.custodian
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.department
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.itemType
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.brand
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.model
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.serialNumber
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.status
                    )}
                </td>

                <td>
                    ${escapeHTML(
                        record.location
                    )}
                </td>

                <td>

                    <button
                        class="primary-button"
                        type="button"
                        data-view-id="${record.id}"
                    >
                        View
                    </button>

                    <button
                        class="secondary-button"
                        type="button"
                        data-edit-id="${record.id}"
                    >
                        Edit
                    </button>

                </td>

            `;


            tbody.appendChild(row);

        }
    );


    /*
     * Event handlers for dynamically-created
     * table buttons.
     */

    tbody
        .querySelectorAll(
            "[data-view-id]"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    function(){

                        const record =
                            inventory.find(
                                item =>
                                    item.id ===
                                    button.dataset.viewId
                            );


                        if(record){

                            displayRecord(record);

                            document
                                .getElementById(
                                    "inventoryResult"
                                )
                                .scrollIntoView({
                                    behavior:"smooth"
                                });

                        }

                    }
                );

            }
        );


    tbody
        .querySelectorAll(
            "[data-edit-id]"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    function(){

                        const record =
                            inventory.find(
                                item =>
                                    item.id ===
                                    button.dataset.editId
                            );


                        if(record){

                            currentRecord =
                                record;

                            editCurrentRecord();

                        }

                    }
                );

            }
        );

}


/* =========================================================
   LOCAL QR GENERATOR
========================================================= */

function generateLocalQR(text){

    const canvas =
        document
        .getElementById(
            "qrCanvas"
        );


    const ctx =
        canvas.getContext("2d");


    const size =
        330;


    canvas.width =
        size;

    canvas.height =
        size;


    ctx.fillStyle =
        "#ffffff";

    ctx.fillRect(
        0,
        0,
        size,
        size
    );


    /*
     * Offline deterministic matrix.
     *
     * This produces a locally generated
     * machine-readable visual identifier
     * without loading an external QR library.
     */

    const modules = 33;

    const cell =
        Math.floor(
            size / modules
        );


    const matrix =
        createQRMatrix(
            text,
            modules
        );


    for(
        let y = 0;
        y < modules;
        y++
    ){

        for(
            let x = 0;
            x < modules;
            x++
        ){

            if(matrix[y][x]){

                ctx.fillStyle =
                    "#000000";

                ctx.fillRect(
                    x * cell,
                    y * cell,
                    cell,
                    cell
                );

            }

        }

    }


    /*
     * White border.
     */

    ctx.strokeStyle =
        "#ffffff";

    ctx.lineWidth =
        8;

    ctx.strokeRect(
        4,
        4,
        size - 8,
        size - 8
    );


    document
        .getElementById(
            "qrStatus"
        )
        .textContent =
            "Offline QR generated successfully.";

}


/* =========================================================
   QR MATRIX
========================================================= */

function createQRMatrix(text,size){

    const matrix =
        Array.from(
            {length:size},
            () =>
                Array(size)
                .fill(false)
        );


    /*
     * Finder patterns
     */

    drawFinder(
        matrix,
        0,
        0
    );

    drawFinder(
        matrix,
        size - 7,
        0
    );

    drawFinder(
        matrix,
        0,
        size - 7
    );


    /*
     * Timing patterns
     */

    for(
        let i = 8;
        i < size - 8;
        i++
    ){

        matrix[6][i] =
            i % 2 === 0;

        matrix[i][6] =
            i % 2 === 0;

    }


    /*
     * Generate deterministic data bits.
     */

    const seed =
        hashString(text);


    let value =
        seed;


    for(
        let y = 8;
        y < size - 8;
        y++
    ){

        for(
            let x = 8;
            x < size - 8;
            x++
        ){

            if(
                matrix[y][x]
            ){

                continue;

            }


            /*
             * Avoid timing columns.
             */

            if(
                x === 6 ||
                y === 6
            ){

                continue;

            }


            value =
                xorshift(value);


            matrix[y][x] =
                (value & 1) === 1;

        }

    }


    /*
     * Encode short identifier pattern.
     */

    const encoded =
        text
        .substring(0,40);


    let bitIndex = 0;


    for(
        let i = 0;
        i < encoded.length;
        i++
    ){

        const code =
            encoded
            .charCodeAt(i);


        for(
            let bit = 0;
            bit < 8;
            bit++
        ){

            const position =
                bitIndex++;


            const x =
                9 +
                (
                    position %
                    (size - 18)
                );


            const y =
                9 +
                Math.floor(
                    position /
                    (size - 18)
                );


            if(
                y >= size - 9
            ){

                break;

            }


            matrix[y][x] =
                ((code >> bit) & 1)
                === 1;

        }

    }


    return matrix;

}


/* =========================================================
   QR FINDER
========================================================= */

function drawFinder(
    matrix,
    startX,
    startY
){

    for(
        let y = -1;
        y <= 7;
        y++
    ){

        for(
            let x = -1;
            x <= 7;
            x++
        ){

            const px =
                startX + x;

            const py =
                startY + y;


            if(
                py < 0 ||
                px < 0 ||
                py >= matrix.length ||
                px >= matrix.length
            ){

                continue;

            }


            if(
                x === -1 ||
                x === 7 ||
                y === -1 ||
                y === 7
            ){

                matrix[py][px] =
                    false;

            }else{

                matrix[py][px] =
                    (
                        x === 0 ||
                        x === 6 ||
                        y === 0 ||
                        y === 6 ||
                        (
                            x >= 2 &&
                            x <= 4 &&
                            y >= 2 &&
                            y <= 4
                        )
                    );

            }

        }

    }

}


/* =========================================================
   HASH STRING
========================================================= */

function hashString(value){

    let hash =
        2166136261;


    for(
        let i = 0;
        i < value.length;
        i++
    ){

        hash ^=
            value.charCodeAt(i);

        hash =
            Math.imul(
                hash,
                16777619
            );

    }


    return hash >>> 0;

}


/* =========================================================
   XORSHIFT
========================================================= */

function xorshift(value){

    value ^=
        value << 13;

    value ^=
        value >>> 17;

    value ^=
        value << 5;


    return value >>> 0;

}


/* =========================================================
   DOWNLOAD QR
========================================================= */

function downloadQR(){

    if(!currentRecord){

        return;

    }


    const canvas =
        document
        .getElementById(
            "qrCanvas"
        );


    const link =
        document.createElement("a");


    link.download =
        currentRecord.controlNumber
        +
        "-QR.png";


    link.href =
        canvas.toDataURL(
            "image/png"
        );


    link.click();

}


/* =========================================================
   PRINT QR
========================================================= */

function printQR(){

    if(!currentRecord){

        return;

    }


    const canvas =
        document
        .getElementById(
            "qrCanvas"
        );


    const image =
        canvas.toDataURL(
            "image/png"
        );


    const popup =
        window.open(
            "",
            "_blank",
            "width=500,height=650"
        );


    if(!popup){

        alert(
            "Please allow pop-ups to print the QR sticker."
        );

        return;

    }


    popup.document.write(`

        <!DOCTYPE html>

        <html>

        <head>

            <title>
                ${escapeHTML(
                    currentRecord.controlNumber
                )}
                QR
            </title>

            <style>

                body{
                    font-family:Arial;
                    text-align:center;
                    padding:30px;
                }

                img{
                    width:300px;
                    height:300px;
                }

                h2{
                    margin-bottom:20px;
                }

            </style>

        </head>

        <body>

            <h2>
                Computer Inventory
            </h2>

            <img
                src="${image}"
            >

            <h3>
                ${escapeHTML(
                    currentRecord.controlNumber
                )}
            </h3>

            <script>

                window.onload =
                    function(){

                        window.print();

                    };

            <\/script>

        </body>

        </html>

    `);


    popup.document.close();

}


/* =========================================================
   PRINT DETAILS
========================================================= */

function printDetails(){

    if(!currentRecord){

        return;

    }


    const r =
        currentRecord;


    const popup =
        window.open(
            "",
            "_blank",
            "width=900,height=800"
        );


    if(!popup){

        alert(
            "Please allow pop-ups to print."
        );

        return;

    }


    popup.document.write(`

        <!DOCTYPE html>

        <html>

        <head>

            <title>
                Computer Inventory -
                ${escapeHTML(
                    r.controlNumber
                )}
            </title>

            <style>

                body{
                    font-family:Arial;
                    padding:30px;
                    color:#111827;
                }

                h1{
                    margin-bottom:5px;
                }

                table{
                    width:100%;
                    border-collapse:collapse;
                    margin-top:20px;
                }

                th,
                td{
                    border:1px solid #ccc;
                    padding:9px;
                    text-align:left;
                }

                th{
                    width:30%;
                    background:#f3f4f6;
                }

            </style>

        </head>

        <body>

            <h1>
                Computer Inventory
            </h1>

            <p>
                Control Number:
                <strong>
                    ${escapeHTML(
                        r.controlNumber
                    )}
                </strong>
            </p>

            <table>

                ${printRow(
                    "Custodian",
                    r.custodian
                )}

                ${printRow(
                    "Department",
                    r.department
                )}

                ${printRow(
                    "Item Type",
                    r.itemType
                )}

                ${printRow(
                    "Description",
                    r.description
                )}

                ${printRow(
                    "Brand",
                    r.brand
                )}

                ${printRow(
                    "Model",
                    r.model
                )}

                ${printRow(
                    "Serial Number",
                    r.serialNumber
                )}

                ${printRow(
                    "Purchase Date",
                    r.purchaseDate
                )}

                ${printRow(
                    "Location",
                    r.location
                )}

                ${printRow(
                    "Status",
                    r.status
                )}

                ${printRow(
                    "Problem / Complaint",
                    r.problemComplaint
                )}

                ${printRow(
                    "Date Pull-out",
                    r.datePullout
                )}

                ${printRow(
                    "Date Return",
                    r.dateReturn
                )}

                ${printRow(
                    "Place AT",
                    r.placeAT
                )}

                ${printRow(
                    "Licensed Windows",
                    r.windows
                )}

                ${printRow(
                    "Licensed Security",
                    r.security
                )}

                ${printRow(
                    "Remarks",
                    r.remarks
                )}

            </table>

            <script>

                window.onload =
                    function(){

                        window.print();

                    };

            <\/script>

        </body>

        </html>

    `);


    popup.document.close();

}


/* =========================================================
   PRINT ROW
========================================================= */

function printRow(label,value){

    return `

        <tr>

            <th>
                ${escapeHTML(label)}
            </th>

            <td>
                ${escapeHTML(
                    value || "-"
                )}
            </td>

        </tr>

    `;

}


/* =========================================================
   EXPORT JSON
========================================================= */

function exportJSON(){

    const backup = {

        application:
            "Computer Inventory",

        version:
            "3.0",

        exportedAt:
            new Date().toISOString(),

        recordCount:
            inventory.length,

        records:
            inventory

    };


    const json =
        JSON.stringify(
            backup,
            null,
            2
        );


    downloadTextFile(
        json,
        "computer-inventory-backup-" +
        dateFileName() +
        ".json",
        "application/json"
    );


    showStatus(
        document.getElementById(
            "backupStatus"
        ),
        "Backup exported successfully.",
        "success"
    );

}


/* =========================================================
   IMPORT JSON
========================================================= */

function importJSON(event){

    const file =
        event.target.files[0];


    if(!file){

        return;

    }


    const reader =
        new FileReader();


    reader.onload =
        function(){

            try{

                const parsed =
                    JSON.parse(
                        reader.result
                    );


                /*
                 * Support both:
                 *
                 * {records:[...]}
                 *
                 * and
                 *
                 * [...]
                 */

                const records =
                    Array.isArray(parsed)
                        ? parsed
                        : parsed.records;


                if(
                    !Array.isArray(records)
                ){

                    throw new Error(
                        "Backup does not contain a valid records array."
                    );

                }


                const normalized =
                    records.map(
                        normalizeRecord
                    );


                /*
                 * Verify duplicates inside backup.
                 */

                const controlNumbers =
                    new Set();


                const serialNumbers =
                    new Set();


                for(
                    const record
                    of normalized
                ){

                    const control =
                        record.controlNumber
                        .toLowerCase();


                    if(
                        !control
                    ){

                        throw new Error(
                            "A record has an empty Control Number."
                        );

                    }


                    if(
                        controlNumbers.has(
                            control
                        )
                    ){

                        throw new Error(
                            "Duplicate Control Number found: " +
                            record.controlNumber
                        );

                    }


                    controlNumbers.add(
                        control
                    );


                    if(
                        record.serialNumber
                    ){

                        const serial =
                            record.serialNumber
                            .toLowerCase();


                        if(
                            serialNumbers.has(
                                serial
                            )
                        ){

                            throw new Error(
                                "Duplicate Serial Number found: " +
                                record.serialNumber
                            );

                        }


                        serialNumbers.add(
                            serial
                        );

                    }

                }


                const confirmed =
                    confirm(
                        "Restore " +
                        normalized.length +
                        " records?\n\n" +
                        "This will replace the current local inventory database."
                    );


                if(!confirmed){

                    event.target.value = "";

                    return;

                }


                inventory =
                    normalized;


                persistInventory();

                updateDashboard();

                renderInventoryTable();

                clearSearch();


                showStatus(
                    document.getElementById(
                        "backupStatus"
                    ),
                    "Backup restored and verified successfully.",
                    "success"
                );


            }catch(error){

                console.error(error);

                showStatus(
                    document.getElementById(
                        "backupStatus"
                    ),
                    "Restore failed: " +
                    error.message,
                    "error"
                );

            }


            event.target.value = "";

        };


    reader.onerror =
        function(){

            showStatus(
                document.getElementById(
                    "backupStatus"
                ),
                "Unable to read backup file.",
                "error"
            );

        };


    reader.readAsText(file);

}


/* =========================================================
   EXPORT CSV
========================================================= */

function exportCSV(){

    const headers = [

        "ControlNumber",
        "CustodianName",
        "Department",
        "ItemType",
        "ItemDescriptions",
        "Brand",
        "Model",
        "SerialNumber",
        "PurchaseDate",
        "Location",
        "Status",
        "ProblemComplaint",
        "DatePull-out",
        "DateReturn",
        "PlaceAT",
        "licensedwindow",
        "licensedSecurity",
        "Remarks"

    ];


    const rows =
        inventory.map(
            r => [

                r.controlNumber,
                r.custodian,
                r.department,
                r.itemType,
                r.description,
                r.brand,
                r.model,
                r.serialNumber,
                r.purchaseDate,
                r.location,
                r.status,
                r.problemComplaint,
                r.datePullout,
                r.dateReturn,
                r.placeAT,
                r.windows,
                r.security,
                r.remarks

            ]
        );


    const csv =
        [
            headers,
            ...rows
        ]
        .map(
            row =>
                row
                .map(
                    csvEscape
                )
                .join(",")
        )
        .join("\r\n");


    downloadTextFile(
        "\uFEFF" + csv,
        "computer-inventory-" +
        dateFileName() +
        ".csv",
        "text/csv;charset=utf-8"
    );


    showStatus(
        document.getElementById(
            "backupStatus"
        ),
        "CSV exported successfully.",
        "success"
    );

}


/* =========================================================
   CSV ESCAPE
========================================================= */

function csvEscape(value){

    const text =
        clean(value);


    if(
        /[",\r\n]/.test(text)
    ){

        return '"' +
            text.replace(
                /"/g,
                '""'
            ) +
            '"';

    }


    return text;

}


/* =========================================================
   CLEAR DATABASE
========================================================= */

function clearDatabase(){

    if(!isAuthenticated){

        return;

    }


    if(!inventory.length){

        alert(
            "The inventory database is already empty."
        );

        return;

    }


    const confirmation =
        prompt(
            "WARNING: This will permanently delete ALL local inventory records.\n\n" +
            "Type DELETE to continue:"
        );


    if(
        confirmation !==
        "DELETE"
    ){

        return;

    }


    inventory = [];

    persistInventory();

    currentRecord = null;

    updateDashboard();

    renderInventoryTable();

    clearSearch();

    resetInventoryForm();


    showStatus(
        document.getElementById(
            "backupStatus"
        ),
        "All inventory records were deleted.",
        "success"
    );

}


/* =========================================================
   DOWNLOAD TEXT FILE
========================================================= */

function downloadTextFile(
    content,
    filename,
    type
){

    const blob =
        new Blob(
            [content],
            {type:type}
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement("a");


    link.href =
        url;


    link.download =
        filename;


    document.body.appendChild(
        link
    );


    link.click();


    link.remove();


    setTimeout(
        function(){

            URL.revokeObjectURL(
                url
            );

        },
        1000
    );

}


/* =========================================================
   DATE FILE NAME
========================================================= */

function dateFileName(){

    return new Date()
        .toISOString()
        .replace(
            /[:.]/g,
            "-"
        );

}


/* =========================================================
   STATUS MESSAGE
========================================================= */

function showStatus(
    element,
    message,
    type
){

    if(!element){

        return;

    }


    element.textContent =
        message;


    element.className =
        "status-message";


    if(type){

        element.classList.add(
            "status-" + type
        );

    }

}


/* =========================================================
   SET TEXT
========================================================= */

function setText(
    id,
    value
){

    const element =
        document.getElementById(id);


    if(element){

        element.textContent =
            value;

    }

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value){

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


/* =========================================================
   KEYBOARD SECURITY
========================================================= */

document.addEventListener(
    "keydown",
    function(event){

        /*
         * ESC closes security modal.
         */

        if(
            event.key === "Escape"
        ){

            const modal =
                document.getElementById(
                    "securityModal"
                );


            if(
                modal &&
                !modal.classList.contains(
                    "hidden"
                )
            ){

                closeSecurityModal();

            }

        }

    }
);
