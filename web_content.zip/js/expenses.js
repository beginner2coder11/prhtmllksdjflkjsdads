/* =========================================================
   PERSONAL FINANCE
   Local-Only Offline Database
   Storage: IndexedDB
========================================================= */

"use strict";


/* =========================================================
   DATABASE CONFIGURATION
========================================================= */

const DB_NAME = "PersonalFinanceLocalDB";
const DB_VERSION = 1;

const STORE_MONTHS = "months";
const STORE_REMINDERS = "reminders";
const STORE_SETTINGS = "settings";


let db = null;


/* =========================================================
   APPLICATION STATE
========================================================= */

const state = {

    currentMonth:
        getCurrentMonthId(),

    currentRecord:
        null,

    settings: {
        currency: "PHP",
        theme: "light",
        locale: "en-PH"
    },

    activeView: "dashboard",

    saveTimer: null,

    toastTimer: null

};


/* =========================================================
   DOM HELPER
========================================================= */

function $(id) {
    return document.getElementById(id);
}


function escapeHtml(value) {

    const div = document.createElement("div");

    div.textContent = value ?? "";

    return div.innerHTML;
}


/* =========================================================
   UNIQUE ID
========================================================= */

function createId(prefix = "id") {

    if (window.crypto && crypto.randomUUID) {

        return `${prefix}_${crypto.randomUUID()}`;

    }

    return `${prefix}_${Date.now()}_${Math.random()
        .toString(36)
        .substring(2, 10)}`;

}


/* =========================================================
   MONTH FUNCTIONS
========================================================= */

function getCurrentMonthId() {

    const now = new Date();

    return `${now.getFullYear()}-${String(
        now.getMonth() + 1
    ).padStart(2, "0")}`;

}


function formatMonth(monthId) {

    if (!monthId) return "";

    const [year, month] =
        monthId.split("-").map(Number);

    const date =
        new Date(year, month - 1, 1);

    return date.toLocaleDateString(
        state.settings.locale,
        {
            month: "long",
            year: "numeric"
        }
    );

}


function changeMonth(monthId, amount) {

    const [year, month] =
        monthId.split("-").map(Number);

    const date =
        new Date(year, month - 1 + amount, 1);

    return `${date.getFullYear()}-${String(
        date.getMonth() + 1
    ).padStart(2, "0")}`;

}


/* =========================================================
   MONEY
========================================================= */

function money(value) {

    const amount =
        Number(value) || 0;

    try {

        return new Intl.NumberFormat(
            state.settings.locale,
            {
                style: "currency",
                currency: state.settings.currency,
                minimumFractionDigits:
                    state.settings.currency === "JPY"
                        ? 0
                        : 2,
                maximumFractionDigits:
                    state.settings.currency === "JPY"
                        ? 0
                        : 2
            }
        ).format(amount);

    } catch {

        return `₱${amount.toFixed(2)}`;

    }

}


function numberValue(value) {

    const number =
        Number(
            String(value)
                .replace(/,/g, "")
                .replace(/[^\d.-]/g, "")
        );

    return Number.isFinite(number)
        ? number
        : 0;

}


/* =========================================================
   DEFAULT RECORD
========================================================= */

function createMonthRecord(monthId) {

    return {

        id: monthId,

        month: monthId,

        incomes: [],

        expenses: [],

        commitments: [],

        notes: "",

        createdAt: new Date().toISOString(),

        updatedAt: new Date().toISOString()

    };

}


/* =========================================================
   DEFAULT SETTINGS
========================================================= */

const DEFAULT_SETTINGS = {

    id: "app",

    currency: "PHP",

    theme: "light",

    locale: "en-PH"

};


/* =========================================================
   INDEXED DB
========================================================= */

function openDatabase() {

    return new Promise((resolve, reject) => {

        const request =
            indexedDB.open(
                DB_NAME,
                DB_VERSION
            );


        request.onupgradeneeded = event => {

            const database =
                event.target.result;


            if (!database.objectStoreNames.contains(STORE_MONTHS)) {

                database.createObjectStore(
                    STORE_MONTHS,
                    {
                        keyPath: "id"
                    }
                );

            }


            if (!database.objectStoreNames.contains(STORE_REMINDERS)) {

                database.createObjectStore(
                    STORE_REMINDERS,
                    {
                        keyPath: "id"
                    }
                );

            }


            if (!database.objectStoreNames.contains(STORE_SETTINGS)) {

                database.createObjectStore(
                    STORE_SETTINGS,
                    {
                        keyPath: "id"
                    }
                );

            }

        };


        request.onsuccess = event => {

            db = event.target.result;

            resolve(db);

        };


        request.onerror = () => {

            reject(request.error);

        };

    });

}


/* =========================================================
   DATABASE HELPERS
========================================================= */

function dbGet(storeName, key) {

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readonly"
            );

        const store =
            transaction.objectStore(
                storeName
            );

        const request =
            store.get(key);

        request.onsuccess = () => {

            resolve(request.result);

        };

        request.onerror = () => {

            reject(request.error);

        };

    });

}


function dbGetAll(storeName) {

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readonly"
            );

        const request =
            transaction
                .objectStore(storeName)
                .getAll();

        request.onsuccess = () => {

            resolve(request.result || []);

        };

        request.onerror = () => {

            reject(request.error);

        };

    });

}


function dbPut(storeName, value) {

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readwrite"
            );

        transaction.objectStore(
            storeName
        ).put(value);

        transaction.oncomplete = () => {

            resolve(true);

        };

        transaction.onerror = () => {

            reject(transaction.error);

        };

    });

}


function dbDelete(storeName, key) {

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readwrite"
            );

        transaction.objectStore(
            storeName
        ).delete(key);

        transaction.oncomplete = () => {

            resolve(true);

        };

        transaction.onerror = () => {

            reject(transaction.error);

        };

    });

}


function dbClear(storeName) {

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                storeName,
                "readwrite"
            );

        transaction.objectStore(
            storeName
        ).clear();

        transaction.oncomplete = () => {

            resolve(true);

        };

        transaction.onerror = () => {

            reject(transaction.error);

        };

    });

}


/* =========================================================
   INITIALIZATION
========================================================= */

async function initializeApp() {

    try {

        await openDatabase();

        await loadSettings();

        await ensureCurrentMonth();

        applyTheme();

        setupEventListeners();

        syncMonthSelectors();

        renderEverything();

        await checkReminders();

        updateNotificationBadge();

        setInterval(
            checkReminders,
            30000
        );

    } catch (error) {

        console.error(error);

        alert(
            "Unable to open the local finance database. " +
            "Please make sure browser storage is enabled."
        );

    }

}


/* =========================================================
   SETTINGS
========================================================= */

async function loadSettings() {

    let settings =
        await dbGet(
            STORE_SETTINGS,
            "app"
        );


    if (!settings) {

        settings =
            {
                ...DEFAULT_SETTINGS
            };

        await dbPut(
            STORE_SETTINGS,
            settings
        );

    }


    state.settings =
        {
            ...DEFAULT_SETTINGS,
            ...settings
        };

}


async function saveSettings() {

    await dbPut(
        STORE_SETTINGS,
        state.settings
    );

}


function applyTheme() {

    document.documentElement
        .setAttribute(
            "data-theme",
            "light"
        );

}


/* =========================================================
   MONTH DATABASE
========================================================= */

async function ensureCurrentMonth() {

    let record =
        await dbGet(
            STORE_MONTHS,
            state.currentMonth
        );


    if (!record) {

        record =
            createMonthRecord(
                state.currentMonth
            );

        await dbPut(
            STORE_MONTHS,
            record
        );

    }


    state.currentRecord = record;

}


async function loadMonth(monthId) {

    let record =
        await dbGet(
            STORE_MONTHS,
            monthId
        );


    if (!record) {

        record =
            createMonthRecord(monthId);

        await dbPut(
            STORE_MONTHS,
            record
        );

    }


    state.currentMonth =
        monthId;

    state.currentRecord =
        record;


    syncMonthSelectors();

    renderEverything();

}


/* =========================================================
   RECORD CALCULATIONS
========================================================= */

function calculateRecord(record) {

    const income =
        (record.incomes || [])
            .reduce(
                (total, item) =>
                    total + numberValue(item.amount),
                0
            );


    const expenses =
        (record.expenses || [])
            .reduce(
                (total, item) =>
                    total + numberValue(item.amount),
                0
            );


    const commitments =
        (record.commitments || [])
            .reduce(
                (total, item) =>
                    total + numberValue(item.amount),
                0
            );


    const balance =
        income -
        expenses -
        commitments;


    const used =
        income > 0
            ? ((expenses + commitments) / income) * 100
            : 0;


    return {

        income,

        expenses,

        commitments,

        balance,

        usedPercentage:
            Math.max(
                0,
                Math.min(
                    100,
                    used
                )
            )

    };

}


/* =========================================================
   RENDER EVERYTHING
========================================================= */

function renderEverything() {

    renderDashboard();

    renderMonthly();

    renderHistory();

    renderReminders();

    renderSettings();

}


/* =========================================================
   DASHBOARD
========================================================= */

function renderDashboard() {

    const record =
        state.currentRecord;

    const totals =
        calculateRecord(record);


    $("dashboardMonth").value =
        state.currentMonth;


    $("dashboardDateText").textContent =
        formatMonth(state.currentMonth);


    $("dashboardIncome").textContent =
        money(totals.income);


    $("dashboardExpenses").textContent =
        money(totals.expenses);


    $("dashboardCommitments").textContent =
        money(totals.commitments);


    $("dashboardBalance").textContent =
        money(totals.balance);


    $("dashboardBalanceText").textContent =
        totals.balance >= 0
            ? "Available after expenses"
            : "Over budget";


    $("allocationIncome").textContent =
        money(totals.income);


    $("allocationExpenses").textContent =
        money(totals.expenses);


    $("allocationCommitments").textContent =
        money(totals.commitments);


    $("allocationBalance").textContent =
        money(totals.balance);


    $("financialHealthScore").textContent =
        `${Math.round(totals.usedPercentage)}%`;


    $("healthUsedText").textContent =
        `${Math.round(totals.usedPercentage)}%`;


    $("healthBarFill").style.width =
        `${totals.usedPercentage}%`;


    const totalItems =
        record.incomes.length +
        record.expenses.length +
        record.commitments.length;


    $("recentSummaryText").textContent =
        totalItems
            ? `${totalItems} financial entr${totalItems === 1 ? "y" : "ies"} recorded`
            : "No financial records yet";


    renderDashboardRecent();

}


/* =========================================================
   DASHBOARD RECENT
========================================================= */

function renderDashboardRecent() {

    const container =
        $("dashboardRecentItems");

    container.innerHTML = "";


    const items = [

        ...(state.currentRecord.incomes || [])
            .map(item => ({
                ...item,
                type: "income"
            })),

        ...(state.currentRecord.expenses || [])
            .map(item => ({
                ...item,
                type: "expense"
            })),

        ...(state.currentRecord.commitments || [])
            .map(item => ({
                ...item,
                type: "commitment"
            }))

    ].slice(-8).reverse();


    if (!items.length) {

        container.innerHTML = `

            <div class="empty-state compact">

                <div class="empty-icon">₱</div>

                <strong>No entries yet</strong>

                <p>
                    Add income, expenses or commitments.
                </p>

            </div>

        `;

        return;

    }


    items.forEach(item => {

        const row =
            document.createElement("div");

        row.className =
            `recent-item recent-${item.type}`;


        const left =
            document.createElement("div");

        left.className =
            "recent-item-left";


        const icon =
            document.createElement("div");

        icon.className =
            "recent-item-icon";

        icon.textContent =
            item.type === "income"
                ? "+"
                : item.type === "expense"
                    ? "−"
                    : "◈";


        const info =
            document.createElement("div");


        const name =
            document.createElement("div");

        name.className =
            "recent-item-name";

        name.textContent =
            item.name ||
            "Unnamed entry";


        const type =
            document.createElement("div");

        type.className =
            "recent-item-type";

        type.textContent =
            item.type === "income"
                ? "Income"
                : item.type === "expense"
                    ? "Expense"
                    : "Commitment";


        info.appendChild(name);
        info.appendChild(type);

        left.appendChild(icon);
        left.appendChild(info);


        const amount =
            document.createElement("strong");

        amount.className =
            "recent-item-amount";

        amount.textContent =
            money(item.amount);


        row.appendChild(left);
        row.appendChild(amount);

        container.appendChild(row);

    });

}


/* =========================================================
   MONTHLY RENDER
========================================================= */

function renderMonthly() {

    const record =
        state.currentRecord;

    const totals =
        calculateRecord(record);


    $("monthlyMonth").value =
        state.currentMonth;


    $("monthlyIncomeTotal").textContent =
        money(totals.income);


    $("monthlyExpenseTotal").textContent =
        money(totals.expenses);


    $("monthlyCommitmentTotal").textContent =
        money(totals.commitments);


    $("monthlyBalanceTotal").textContent =
        money(totals.balance);


    $("incomeFooterTotal").textContent =
        money(totals.income);


    $("expenseFooterTotal").textContent =
        money(totals.expenses);


    $("commitmentFooterTotal").textContent =
        money(totals.commitments);


    $("finalRemainingBalance").textContent =
        money(totals.balance);


    $("finalBalanceMessage").textContent =
        totals.balance >= 0
            ? "Your planned income covers your expenses and commitments."
            : "Your planned expenses are higher than your available income.";


    $("monthlyNotes").value =
        record.notes || "";


    $("lastSavedText").textContent =
        record.updatedAt
            ? formatDateTime(record.updatedAt)
            : "Not saved yet";


    renderTransactionList(
        "incomeList",
        "income",
        record.incomes
    );


    renderTransactionList(
        "expenseList",
        "expense",
        record.expenses
    );


    renderTransactionList(
        "commitmentList",
        "commitment",
        record.commitments
    );

}


/* =========================================================
   TRANSACTION LIST
========================================================= */

function renderTransactionList(
    containerId,
    type,
    items
) {

    const container =
        $(containerId);

    container.innerHTML = "";


    if (!items.length) {

        const empty =
            document.createElement("div");

        empty.className =
            "empty-transaction";

        empty.textContent =
            `No ${type} entries. Click "+ Add" to create one.`;

        container.appendChild(empty);

        return;

    }


    items.forEach(item => {

        const row =
            document.createElement("div");

        row.className =
            "transaction-row";

        row.dataset.type =
            type;

        row.dataset.id =
            item.id;


        const name =
            document.createElement("input");

        name.type =
            "text";

        name.className =
            "item-name";

        name.placeholder =
            "Description";

        name.value =
            item.name || "";


        const amount =
            document.createElement("input");

        amount.type =
            "number";

        amount.inputMode =
            "decimal";

        amount.step =
            "0.01";

        amount.min =
            "0";

        amount.className =
            "amount-input";

        amount.placeholder =
            "0.00";

        amount.value =
            item.amount || "";


        const note =
            document.createElement("input");

        note.type =
            "text";

        note.className =
            "note-input";

        note.placeholder =
            "Optional note";

        note.value =
            item.note || "";


        const deleteButton =
            document.createElement("button");

        deleteButton.type =
            "button";

        deleteButton.className =
            "delete-row-button";

        deleteButton.dataset.deleteType =
            type;

        deleteButton.dataset.deleteId =
            item.id;

        deleteButton.textContent =
            "×";


        row.appendChild(name);
        row.appendChild(amount);
        row.appendChild(note);
        row.appendChild(deleteButton);

        container.appendChild(row);

    });

}


/* =========================================================
   ADD TRANSACTION
========================================================= */

async function addTransaction(type) {

    const key =
        type === "income"
            ? "incomes"
            : type === "expense"
                ? "expenses"
                : "commitments";


    const item = {

        id: createId(type),

        name:
            type === "income"
                ? "New Income"
                : type === "expense"
                    ? "New Expense"
                    : "New Commitment",

        amount: 0,

        note: ""

    };


    state.currentRecord[key].push(item);

    state.currentRecord.updatedAt =
        new Date().toISOString();


    await saveCurrentRecord(false);

    renderEverything();

    showView("monthly");


    setTimeout(() => {

        const input =
            document.querySelector(
                `[data-type="${type}"][data-id="${item.id}"] .item-name`
            );

        if (input) {

            input.focus();

            input.select();

        }

    }, 50);

}


/* =========================================================
   DELETE TRANSACTION
========================================================= */

async function deleteTransaction(
    type,
    id
) {

    const confirmed =
        await confirmAction(
            "Delete Entry",
            "Remove this financial entry from the current month?"
        );


    if (!confirmed) return;


    const key =
        type === "income"
            ? "incomes"
            : type === "expense"
                ? "expenses"
                : "commitments";


    state.currentRecord[key] =
        state.currentRecord[key]
            .filter(item =>
                item.id !== id
            );


    state.currentRecord.updatedAt =
        new Date().toISOString();


    await saveCurrentRecord(false);

    renderEverything();

    showToast(
        "Deleted",
        "Financial entry removed.",
        "✓"
    );

}


/* =========================================================
   UPDATE TRANSACTION FROM INPUT
========================================================= */

function updateTransactionFromInput(
    input
) {

    const row =
        input.closest(".transaction-row");

    if (!row) return;


    const type =
        row.dataset.type;

    const id =
        row.dataset.id;


    const key =
        type === "income"
            ? "incomes"
            : type === "expense"
                ? "expenses"
                : "commitments";


    const item =
        state.currentRecord[key]
            .find(entry =>
                entry.id === id
            );


    if (!item) return;


    if (input.classList.contains("item-name")) {

        item.name =
            input.value;

    }


    if (input.classList.contains("amount-input")) {

        item.amount =
            numberValue(input.value);

    }


    if (input.classList.contains("note-input")) {

        item.note =
            input.value;

    }


    state.currentRecord.updatedAt =
        new Date().toISOString();


    updateTotalsOnly();

    scheduleAutoSave();

}


/* =========================================================
   UPDATE NOTES
========================================================= */

function updateNotes() {

    state.currentRecord.notes =
        $("monthlyNotes").value;

    state.currentRecord.updatedAt =
        new Date().toISOString();

    scheduleAutoSave();

}


/* =========================================================
   AUTO SAVE
========================================================= */

function scheduleAutoSave() {

    clearTimeout(
        state.saveTimer
    );


    state.saveTimer =
        setTimeout(
            () => saveCurrentRecord(false),
            600
        );

}


async function saveCurrentRecord(showMessage = true) {

    state.currentRecord.updatedAt =
        new Date().toISOString();


    await dbPut(
        STORE_MONTHS,
        state.currentRecord
    );


    if (showMessage) {

        renderEverything();

        showToast(
            "Saved",
            `${formatMonth(state.currentMonth)} saved locally.`,
            "✓"
        );

    }

}


/* =========================================================
   UPDATE TOTALS WITHOUT FULL RENDER
========================================================= */

function updateTotalsOnly() {

    const totals =
        calculateRecord(
            state.currentRecord
        );


    $("monthlyIncomeTotal").textContent =
        money(totals.income);

    $("monthlyExpenseTotal").textContent =
        money(totals.expenses);

    $("monthlyCommitmentTotal").textContent =
        money(totals.commitments);

    $("monthlyBalanceTotal").textContent =
        money(totals.balance);

    $("incomeFooterTotal").textContent =
        money(totals.income);

    $("expenseFooterTotal").textContent =
        money(totals.expenses);

    $("commitmentFooterTotal").textContent =
        money(totals.commitments);

    $("finalRemainingBalance").textContent =
        money(totals.balance);


    renderDashboard();

}


/* =========================================================
   DUPLICATE MONTH
========================================================= */

async function duplicateMonth() {

    const nextMonth =
        changeMonth(
            state.currentMonth,
            1
        );


    const existing =
        await dbGet(
            STORE_MONTHS,
            nextMonth
        );


    if (existing) {

        const confirmed =
            await confirmAction(
                "Replace Next Month?",
                `${formatMonth(nextMonth)} already exists. Replace it with a copy of this month?`
            );

        if (!confirmed) return;

    }


    const copy =
        JSON.parse(
            JSON.stringify(
                state.currentRecord
            )
        );


    copy.id =
        nextMonth;

    copy.month =
        nextMonth;

    copy.createdAt =
        new Date().toISOString();

    copy.updatedAt =
        new Date().toISOString();


    await dbPut(
        STORE_MONTHS,
        copy
    );


    await loadMonth(nextMonth);

    showToast(
        "Month Duplicated",
        `Copied to ${formatMonth(nextMonth)}.`,
        "✓"
    );

}


/* =========================================================
   HISTORY
========================================================= */

async function renderHistory() {

    const records =
        await dbGetAll(
            STORE_MONTHS
        );


    const search =
        (
            $("historySearch")?.value ||
            ""
        ).toLowerCase().trim();


    const filter =
        $("historyFilter")?.value ||
        "all";


    let filtered =
        records.filter(record => {

            const totals =
                calculateRecord(record);


            const matchesSearch =
                formatMonth(record.month)
                    .toLowerCase()
                    .includes(search) ||
                record.month
                    .toLowerCase()
                    .includes(search);


            let matchesFilter = true;


            if (filter === "positive") {

                matchesFilter =
                    totals.balance >= 0;

            }


            if (filter === "negative") {

                matchesFilter =
                    totals.balance < 0;

            }


            if (filter === "income") {

                matchesFilter =
                    totals.income > 0;

            }


            if (filter === "expenses") {

                matchesFilter =
                    totals.expenses > 0;

            }


            return (
                matchesSearch &&
                matchesFilter
            );

        });


    filtered.sort(
        (a, b) =>
            b.month.localeCompare(a.month)
    );


    const container =
        $("historyList");

    container.innerHTML = "";


    if (!filtered.length) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">◷</div>

                <strong>No monthly records</strong>

                <p>
                    Your saved monthly records will appear here.
                </p>

            </div>

        `;

        return;

    }


    filtered.forEach(record => {

        const totals =
            calculateRecord(record);


        const card =
            document.createElement("div");

        card.className =
            "history-card";


        const top =
            document.createElement("div");

        top.className =
            "history-card-top";


        const month =
            document.createElement("div");

        month.innerHTML = `

            <div class="history-month">
                ${escapeHtml(
                    formatMonth(record.month)
                )}
            </div>

            <div class="history-date">
                Updated ${escapeHtml(
                    formatDateTime(record.updatedAt)
                )}
            </div>

        `;


        const balance =
            document.createElement("div");

        balance.className =
            "history-balance";


        const balanceLabel =
            document.createElement("span");

        balanceLabel.textContent =
            "Remaining";


        const balanceValue =
            document.createElement("strong");

        balanceValue.className =
            totals.balance >= 0
                ? "positive-balance"
                : "negative-balance";

        balanceValue.textContent =
            money(totals.balance);


        balance.appendChild(
            balanceLabel
        );

        balance.appendChild(
            balanceValue
        );


        top.appendChild(month);
        top.appendChild(balance);


        const stats =
            document.createElement("div");

        stats.className =
            "history-stats";


        stats.appendChild(
            createHistoryStat(
                "Income",
                money(totals.income)
            )
        );


        stats.appendChild(
            createHistoryStat(
                "Expenses",
                money(totals.expenses)
            )
        );


        stats.appendChild(
            createHistoryStat(
                "Commitments",
                money(totals.commitments)
            )
        );


        const actions =
            document.createElement("div");

        actions.className =
            "history-actions";


        const open =
            document.createElement("button");

        open.className =
            "secondary-button";

        open.textContent =
            "Open";

        open.dataset.openMonth =
            record.month;


        const deleteButton =
            document.createElement("button");

        deleteButton.className =
            "danger-button";

        deleteButton.textContent =
            "Delete";

        deleteButton.dataset.deleteMonth =
            record.month;


        actions.appendChild(open);
        actions.appendChild(deleteButton);


        card.appendChild(top);
        card.appendChild(stats);
        card.appendChild(actions);

        container.appendChild(card);

    });

}


function createHistoryStat(
    label,
    value
) {

    const div =
        document.createElement("div");

    div.className =
        "history-stat";


    const span =
        document.createElement("span");

    span.textContent =
        label;


    const strong =
        document.createElement("strong");

    strong.textContent =
        value;


    div.appendChild(span);
    div.appendChild(strong);


    return div;

}


/* =========================================================
   DELETE MONTH
========================================================= */

async function deleteMonth(monthId) {

    const confirmed =
        await confirmAction(
            "Delete Monthly Record",
            `Delete the complete ${formatMonth(monthId)} record? This cannot be undone.`
        );


    if (!confirmed) return;


    await dbDelete(
        STORE_MONTHS,
        monthId
    );


    if (monthId === state.currentMonth) {

        await ensureCurrentMonth();

    }


    renderEverything();

    showToast(
        "Deleted",
        `${formatMonth(monthId)} was removed.`,
        "✓"
    );

}


/* =========================================================
   REMINDERS
========================================================= */

async function renderReminders() {

    const reminders =
        await dbGetAll(
            STORE_REMINDERS
        );


    reminders.sort(
        (a, b) =>
            new Date(a.nextAt) -
            new Date(b.nextAt)
    );


    const container =
        $("reminderList");

    container.innerHTML = "";


    if (!reminders.length) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">♧</div>

                <strong>No reminders</strong>

                <p>
                    Add bills, loans or financial reminders.
                </p>

            </div>

        `;

        updateNotificationBadge();

        return;

    }


    reminders.forEach(reminder => {

        const row =
            document.createElement("div");

        row.className =
            "reminder-item";


        const left =
            document.createElement("div");

        left.className =
            "reminder-left";


        const icon =
            document.createElement("div");

        icon.className =
            "reminder-icon";

        icon.textContent =
            "🔔";


        const information =
            document.createElement("div");


        const title =
            document.createElement("div");

        title.className =
            "reminder-title";

        title.textContent =
            reminder.title;


        const date =
            document.createElement("div");

        date.className =
            "reminder-date";

        date.textContent =
            formatReminderDate(
                reminder.nextAt
            );


        information.appendChild(title);
        information.appendChild(date);


        left.appendChild(icon);
        left.appendChild(information);


        const actions =
            document.createElement("div");

        actions.className =
            "reminder-actions";


        const toggle =
            document.createElement("button");

        toggle.textContent =
            reminder.enabled
                ? "✓"
                : "○";

        toggle.title =
            reminder.enabled
                ? "Disable"
                : "Enable";

        toggle.dataset.toggleReminder =
            reminder.id;


        const remove =
            document.createElement("button");

        remove.textContent =
            "×";

        remove.title =
            "Delete";

        remove.dataset.deleteReminder =
            reminder.id;


        actions.appendChild(toggle);
        actions.appendChild(remove);


        row.appendChild(left);
        row.appendChild(actions);

        container.appendChild(row);

    });


    updateNotificationBadge();

}


/* =========================================================
   ADD REMINDER
========================================================= */

async function addReminder(event) {

    event.preventDefault();


    const title =
        $("reminderTitle")
            .value
            .trim();

    const date =
        $("reminderDate").value;

    const time =
        $("reminderTime").value;

    const repeat =
        $("reminderRepeat").value;


    if (!title || !date || !time) {

        showToast(
            "Incomplete",
            "Please fill in the reminder details.",
            "!"
        );

        return;

    }


    const nextAt =
        new Date(
            `${date}T${time}:00`
        );


    const reminder = {

        id:
            createId("reminder"),

        title,

        nextAt:
            nextAt.toISOString(),

        repeat,

        enabled: true,

        createdAt:
            new Date().toISOString()

    };


    await dbPut(
        STORE_REMINDERS,
        reminder
    );


    $("reminderForm").reset();

    $("reminderTime").value =
        "08:00";


    await renderReminders();


    showToast(
        "Reminder Saved",
        "Reminder stored locally.",
        "✓"
    );

}


/* =========================================================
   CHECK REMINDERS
========================================================= */

async function checkReminders() {

    if (!db) return;


    const reminders =
        await dbGetAll(
            STORE_REMINDERS
        );


    const now =
        new Date();


    for (const reminder of reminders) {

        if (!reminder.enabled) {
            continue;
        }


        const due =
            new Date(
                reminder.nextAt
            );


        if (due > now) {
            continue;
        }


        const lastTriggered =
            reminder.lastTriggered
                ? new Date(
                    reminder.lastTriggered
                )
                : null;


        if (
            lastTriggered &&
            now - lastTriggered <
                60000
        ) {
            continue;
        }


        reminder.lastTriggered =
            now.toISOString();


        showToast(
            "Financial Reminder",
            reminder.title,
            "🔔"
        );


        sendBrowserNotification(
            reminder.title,
            "Personal Finance reminder"
        );


        if (reminder.repeat === "none") {

            reminder.enabled =
                false;

        } else {

            reminder.nextAt =
                getNextReminderDate(
                    due,
                    reminder.repeat
                ).toISOString();

        }


        await dbPut(
            STORE_REMINDERS,
            reminder
        );

    }


    await renderReminders();

}


function getNextReminderDate(
    date,
    repeat
) {

    const next =
        new Date(date);


    if (repeat === "daily") {

        next.setDate(
            next.getDate() + 1
        );

    }


    if (repeat === "weekly") {

        next.setDate(
            next.getDate() + 7
        );

    }


    if (repeat === "monthly") {

        next.setMonth(
            next.getMonth() + 1
        );

    }


    return next;

}


/* =========================================================
   NOTIFICATIONS
========================================================= */

async function requestNotificationPermission() {

    if (
        !("Notification" in window)
    ) {

        showToast(
            "Not Supported",
            "This browser does not support notifications.",
            "!"
        );

        return;

    }


    const permission =
        await Notification.requestPermission();


    if (permission === "granted") {

        showToast(
            "Notifications Enabled",
            "Local reminders are enabled.",
            "✓"
        );

        sendBrowserNotification(
            "Personal Finance",
            "Notifications are now enabled."
        );

    } else {

        showToast(
            "Notifications Disabled",
            "You can enable them in browser settings.",
            "!"
        );

    }

}


function sendBrowserNotification(
    title,
    body
) {

    if (
        "Notification" in window &&
        Notification.permission === "granted"
    ) {

        try {

            new Notification(
                title,
                {
                    body,
                    icon: "",
                    tag: "personal-finance"
                }
            );

        } catch (error) {

            console.warn(
                "Notification failed:",
                error
            );

        }

    }

}


async function updateNotificationBadge() {

    if (!db) return;


    const reminders =
        await dbGetAll(
            STORE_REMINDERS
        );


    const count =
        reminders.filter(
            reminder =>
                reminder.enabled &&
                new Date(reminder.nextAt) <= new Date()
        ).length;


    const badge =
        $("notificationBadge");


    badge.textContent =
        count;


    badge.classList.toggle(
        "hidden",
        count === 0
    );

}


/* =========================================================
   EXPORT DATABASE
========================================================= */

async function exportDatabase() {

    const months =
        await dbGetAll(
            STORE_MONTHS
        );


    const reminders =
        await dbGetAll(
            STORE_REMINDERS
        );


    const settings =
        await dbGetAll(
            STORE_SETTINGS
        );


    const database = {

        application:
            "Personal Finance",

        version:
            "2.0 Local",

        exportedAt:
            new Date().toISOString(),

        storage:
            "IndexedDB",

        months,

        reminders,

        settings

    };


    const filename =
        `personal-finance-backup-${getCurrentMonthId()}.json`;


    downloadFile(
        filename,
        JSON.stringify(
            database,
            null,
            2
        ),
        "application/json"
    );


    showToast(
        "Backup Exported",
        "Your complete local database was exported.",
        "✓"
    );

}


/* =========================================================
   IMPORT DATABASE
========================================================= */

async function importDatabase(file) {

    if (!file) return;


    try {

        const text =
            await file.text();


        const database =
            JSON.parse(text);


        if (
            !database ||
            !Array.isArray(database.months)
        ) {

            throw new Error(
                "Invalid finance database."
            );

        }


        const confirmed =
            await confirmAction(
                "Restore Database",
                "Restoring this file will replace the current local finance database. Continue?"
            );


        if (!confirmed) return;


        await dbClear(
            STORE_MONTHS
        );

        await dbClear(
            STORE_REMINDERS
        );

        await dbClear(
            STORE_SETTINGS
        );


        for (
            const month
            of database.months
        ) {

            await dbPut(
                STORE_MONTHS,
                month
            );

        }


        for (
            const reminder
            of database.reminders || []
        ) {

            await dbPut(
                STORE_REMINDERS,
                reminder
            );

        }


        for (
            const setting
            of database.settings || []
        ) {

            await dbPut(
                STORE_SETTINGS,
                setting
            );

        }


        await loadSettings();


        state.currentMonth =
            getCurrentMonthId();


        await ensureCurrentMonth();


        renderEverything();


        showToast(
            "Database Restored",
            "Your local finance database has been restored.",
            "✓"
        );

    } catch (error) {

        console.error(error);

        showToast(
            "Import Failed",
            "The selected file is not a valid finance backup.",
            "!"
        );

    }

}


/* =========================================================
   CSV EXPORT
========================================================= */

async function exportCurrentMonthCSV() {

    const record =
        state.currentRecord;


    const rows = [

        [
            "Month",
            "Type",
            "Description",
            "Amount",
            "Notes"
        ]

    ];


    record.incomes.forEach(item => {

        rows.push([
            record.month,
            "Income",
            item.name || "",
            item.amount || 0,
            item.note || ""
        ]);

    });


    record.expenses.forEach(item => {

        rows.push([
            record.month,
            "Expense",
            item.name || "",
            item.amount || 0,
            item.note || ""
        ]);

    });


    record.commitments.forEach(item => {

        rows.push([
            record.month,
            "Commitment",
            item.name || "",
            item.amount || 0,
            item.note || ""
        ]);

    });


    const totals =
        calculateRecord(record);


    rows.push([]);

    rows.push([
        "",
        "TOTAL INCOME",
        "",
        totals.income,
        ""
    ]);


    rows.push([
        "",
        "TOTAL EXPENSES",
        "",
        totals.expenses,
        ""
    ]);


    rows.push([
        "",
        "TOTAL COMMITMENTS",
        "",
        totals.commitments,
        ""
    ]);


    rows.push([
        "",
        "REMAINING BALANCE",
        "",
        totals.balance,
        ""
    ]);


    const csv =
        rows.map(
            row =>
                row.map(
                    cell =>
                        csvEscape(cell)
                ).join(",")
        ).join("\n");


    downloadFile(
        `personal-finance-${record.month}.csv`,
        csv,
        "text/csv;charset=utf-8"
    );


    showToast(
        "CSV Exported",
        "Current month exported successfully.",
        "✓"
    );

}


function csvEscape(value) {

    const text =
        String(value ?? "");


    if (
        text.includes(",") ||
        text.includes('"') ||
        text.includes("\n")
    ) {

        return `"${text.replace(
            /"/g,
            '""'
        )}"`;

    }


    return text;

}


/* =========================================================
   PRINT
========================================================= */

async function printReport() {

    await saveCurrentRecord(false);

    showView("monthly");


    setTimeout(() => {

        window.print();

    }, 250);

}


/* =========================================================
   DOWNLOAD FILE
========================================================= */

function downloadFile(
    filename,
    content,
    mime
) {

    const blob =
        new Blob(
            [content],
            {
                type: mime
            }
        );


    const url =
        URL.createObjectURL(blob);


    const anchor =
        document.createElement("a");

    anchor.href =
        url;

    anchor.download =
        filename;

    document.body.appendChild(anchor);

    anchor.click();

    anchor.remove();


    setTimeout(
        () => URL.revokeObjectURL(url),
        1000
    );

}


/* =========================================================
   SAMPLE DATA
========================================================= */

async function loadSampleData() {

    const confirmed =
        await confirmAction(
            "Load Example Data",
            "This will replace the current month's entries with sample data."
        );


    if (!confirmed) return;


    state.currentRecord =
        createMonthRecord(
            state.currentMonth
        );


    state.currentRecord.incomes = [

        {
            id: createId("income"),
            name: "Salary",
            amount: 20000,
            note: "Monthly salary"
        },

        {
            id: createId("income"),
            name: "Rice Allowance",
            amount: 3000,
            note: ""
        },

        {
            id: createId("income"),
            name: "COLA",
            amount: 440,
            note: ""
        },

        {
            id: createId("income"),
            name: "Load Allowance",
            amount: 200,
            note: ""
        }

    ];


    state.currentRecord.expenses = [

        {
            id: createId("expense"),
            name: "Shelter",
            amount: 2500,
            note: ""
        },

        {
            id: createId("expense"),
            name: "TV",
            amount: 2185,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Electricity",
            amount: 1300,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Water",
            amount: 450,
            note: ""
        },

        {
            id: createId("expense"),
            name: "WiFi",
            amount: 300,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Rice",
            amount: 500,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Groceries",
            amount: 4000,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Ulam",
            amount: 3000,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Gasul",
            amount: 360,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Sabon / Shampoo",
            amount: 300,
            note: ""
        },

        {
            id: createId("expense"),
            name: "Gasoline",
            amount: 500,
            note: ""
        }

    ];


    state.currentRecord.commitments = [

        {
            id: createId("commitment"),
            name: "Salary Loan",
            amount: 2459.84,
            note: ""
        },

        {
            id: createId("commitment"),
            name: "CBU",
            amount: 100,
            note: ""
        },

        {
            id: createId("commitment"),
            name: "Motor Loan",
            amount: 631.66,
            note: ""
        },

        {
            id: createId("commitment"),
            name: "SSS / Pag-IBIG / PhilHealth",
            amount: 1675,
            note: ""
        },

        {
            id: createId("commitment"),
            name: "Saving Deposit",
            amount: 1500,
            note: ""
        }

    ];


    state.currentRecord.notes =
        "Monthly personal finance example.";


    state.currentRecord.updatedAt =
        new Date().toISOString();


    await dbPut(
        STORE_MONTHS,
        state.currentRecord
    );


    renderEverything();

    showView("monthly");


    showToast(
        "Example Loaded",
        "Sample financial data has been added.",
        "✓"
    );

}


/* =========================================================
   DELETE ALL DATA
========================================================= */

async function deleteAllData() {

    const confirmed =
        await confirmAction(
            "Delete Everything",
            "This permanently deletes all monthly records, reminders and settings from this phone. This cannot be undone."
        );


    if (!confirmed) return;


    const secondConfirm =
        await confirmAction(
            "Final Confirmation",
            "Are you absolutely sure you want to erase all personal finance data?"
        );


    if (!secondConfirm) return;


    await dbClear(
        STORE_MONTHS
    );

    await dbClear(
        STORE_REMINDERS
    );

    await dbClear(
        STORE_SETTINGS
    );


    state.settings =
        {
            ...DEFAULT_SETTINGS
        };


    await saveSettings();


    state.currentMonth =
        getCurrentMonthId();


    await ensureCurrentMonth();


    renderEverything();


    showToast(
        "Data Deleted",
        "All local finance data has been removed.",
        "✓"
    );

}


/* =========================================================
   NAVIGATION
========================================================= */

function showView(viewName) {

    state.activeView =
        viewName;


    document
        .querySelectorAll(".app-view")
        .forEach(view => {

            view.classList.toggle(
                "active",
                view.id ===
                `view-${viewName}`
            );

        });


    document
        .querySelectorAll(".nav-item")
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.view ===
                viewName
            );

        });


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });


    if (viewName === "history") {

        renderHistory();

    }


    if (viewName === "reminders") {

        renderReminders();

    }


    if (viewName === "backup") {

        // No remote data is loaded.

    }

}


/* =========================================================
   MONTH SELECTORS
========================================================= */

function syncMonthSelectors() {

    $("dashboardMonth").value =
        state.currentMonth;

    $("monthlyMonth").value =
        state.currentMonth;

}


async function handleMonthChange(
    value
) {

    if (!value) return;

    await loadMonth(value);

}


/* =========================================================
   FORMAT DATES
========================================================= */

function formatDateTime(
    iso
) {

    if (!iso) return "Never";


    const date =
        new Date(iso);


    if (Number.isNaN(date.getTime())) {

        return "Unknown";

    }


    return date.toLocaleString(
        state.settings.locale,
        {
            dateStyle: "medium",
            timeStyle: "short"
        }
    );

}


function formatReminderDate(
    iso
) {

    const date =
        new Date(iso);


    if (Number.isNaN(date.getTime())) {

        return "Invalid date";

    }


    return date.toLocaleString(
        state.settings.locale,
        {
            dateStyle: "medium",
            timeStyle: "short"
        }
    );

}


/* =========================================================
   QUICK ADD
========================================================= */

function openQuickAdd() {

    $("quickAddModal")
        .classList.remove(
            "hidden"
        );

}


function closeModal(id) {

    $(id)
        ?.classList.add(
            "hidden"
        );

}


/* =========================================================
   CONFIRM ACTION
========================================================= */

function confirmAction(
    title,
    message
) {

    return new Promise(resolve => {

        $("confirmTitle")
            .textContent =
            title;

        $("confirmMessage")
            .textContent =
            message;


        const modal =
            $("confirmModal");

        modal.classList.remove(
            "hidden"
        );


        const ok =
            $("confirmOkButton");

        const cancel =
            $("confirmCancelButton");


        const cleanup = result => {

            modal.classList.add(
                "hidden"
            );


            ok.onclick =
                null;

            cancel.onclick =
                null;


            resolve(result);

        };


        ok.onclick =
            () => cleanup(true);

        cancel.onclick =
            () => cleanup(false);

    });

}


/* =========================================================
   TOAST
========================================================= */

function showToast(
    title,
    message,
    icon = "✓"
) {

    const toast =
        $("toast");


    $("toastTitle")
        .textContent =
        title;


    $("toastMessage")
        .textContent =
        message;


    $("toastIcon")
        .textContent =
        icon;


    toast.classList.add(
        "show"
    );


    clearTimeout(
        state.toastTimer
    );


    state.toastTimer =
        setTimeout(
            () => {

                toast.classList.remove(
                    "show"
                );

            },
            3000
        );

}


/* =========================================================
   EVENT LISTENERS
========================================================= */

function setupEventListeners() {


    /* Navigation */

    document
        .querySelectorAll(".nav-item")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    showView(
                        button.dataset.view
                    );

                }
            );

        });


    /* Dashboard month */

    $("dashboardMonth")
        .addEventListener(
            "change",
            event =>
                handleMonthChange(
                    event.target.value
                )
        );


    $("monthlyMonth")
        .addEventListener(
            "change",
            event =>
                handleMonthChange(
                    event.target.value
                )
        );


    $("previousMonthButton")
        .addEventListener(
            "click",
            () =>
                handleMonthChange(
                    changeMonth(
                        state.currentMonth,
                        -1
                    )
                )
        );


    $("nextMonthButton")
        .addEventListener(
            "click",
            () =>
                handleMonthChange(
                    changeMonth(
                        state.currentMonth,
                        1
                    )
                )
        );


    /* Add buttons */

    document
        .querySelectorAll("[data-add-type]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () =>
                    addTransaction(
                        button.dataset.addType
                    )
            );

        });


    /* Quick actions */

    document
        .querySelectorAll("[data-action]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const action =
                        button.dataset.action;


                    if (
                        action ===
                        "add-income"
                    ) {

                        addTransaction(
                            "income"
                        );

                    }


                    if (
                        action ===
                        "add-expense"
                    ) {

                        addTransaction(
                            "expense"
                        );

                    }


                    if (
                        action ===
                        "add-commitment"
                    ) {

                        addTransaction(
                            "commitment"
                        );

                    }


                    if (
                        action ===
                        "open-month"
                    ) {

                        showView(
                            "monthly"
                        );

                    }

                }
            );

        });


    /* Quick Add */

    $("quickAddButton")
        .addEventListener(
            "click",
            openQuickAdd
        );


    $("notificationButton")
        .addEventListener(
            "click",
            () => {

                showView(
                    "reminders"
                );

            }
        );


    document
        .querySelectorAll("[data-close-modal]")
        .forEach(button => {

            button.addEventListener(
                "click",
                () =>
                    closeModal(
                        button.dataset.closeModal
                    )
            );

        });


    document
        .querySelectorAll("[data-quick-type]")
        .forEach(button => {

            button.addEventListener(
                "click",
                async () => {

                    closeModal(
                        "quickAddModal"
                    );

                    await addTransaction(
                        button.dataset.quickType
                    );

                }
            );

        });


    /* Transaction input changes */

    document.addEventListener(
        "input",
        event => {

            if (
                event.target.closest(
                    ".transaction-row"
                )
            ) {

                updateTransactionFromInput(
                    event.target
                );

            }

        }
    );


    /* Transaction delete */

    document.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "[data-delete-type]"
                );


            if (!button) return;


            deleteTransaction(
                button.dataset.deleteType,
                button.dataset.deleteId
            );

        }
    );


    /* Monthly notes */

    $("monthlyNotes")
        .addEventListener(
            "input",
            updateNotes
        );


    /* Save */

    $("saveMonthButton")
        .addEventListener(
            "click",
            () =>
                saveCurrentRecord(true)
        );


    /* Duplicate */

    $("duplicateMonthButton")
        .addEventListener(
            "click",
            duplicateMonth
        );


    /* History search */

    $("historySearch")
        .addEventListener(
            "input",
            renderHistory
        );


    $("historyFilter")
        .addEventListener(
            "change",
            renderHistory
        );


    $("createCurrentMonthButton")
        .addEventListener(
            "click",
            async () => {

                await ensureCurrentMonth();

                renderEverything();

                showView("monthly");

            }
        );


    /* History actions */

    document.addEventListener(
        "click",
        event => {

            const openButton =
                event.target.closest(
                    "[data-open-month]"
                );


            if (openButton) {

                loadMonth(
                    openButton.dataset.openMonth
                );

                showView(
                    "monthly"
                );

                return;

            }


            const deleteButton =
                event.target.closest(
                    "[data-delete-month]"
                );


            if (deleteButton) {

                deleteMonth(
                    deleteButton.dataset.deleteMonth
                );

            }

        }
    );


    /* Reminders */

    $("reminderForm")
        .addEventListener(
            "submit",
            addReminder
        );


    $("requestNotificationButton")
        .addEventListener(
            "click",
            requestNotificationPermission
        );


    $("settingsNotificationButton")
        .addEventListener(
            "click",
            requestNotificationPermission
        );


    /* Reminder actions */

    document.addEventListener(
        "click",
        async event => {

            const toggle =
                event.target.closest(
                    "[data-toggle-reminder]"
                );


            if (toggle) {

                const reminder =
                    await dbGet(
                        STORE_REMINDERS,
                        toggle.dataset.toggleReminder
                    );


                if (reminder) {

                    reminder.enabled =
                        !reminder.enabled;

                    await dbPut(
                        STORE_REMINDERS,
                        reminder
                    );

                    renderReminders();

                }

            }


            const remove =
                event.target.closest(
                    "[data-delete-reminder]"
                );


            if (remove) {

                const confirmed =
                    await confirmAction(
                        "Delete Reminder",
                        "Remove this reminder?"
                    );


                if (!confirmed) return;


                await dbDelete(
                    STORE_REMINDERS,
                    remove.dataset.deleteReminder
                );


                renderReminders();


                showToast(
                    "Reminder Deleted",
                    "Reminder removed.",
                    "✓"
                );

            }

        }
    );


    /* Export */

    $("exportJsonButton")
        .addEventListener(
            "click",
            exportDatabase
        );


    $("exportCsvButton")
        .addEventListener(
            "click",
            exportCurrentMonthCSV
        );


    $("printReportButton")
        .addEventListener(
            "click",
            printReport
        );


    /* Import */

    $("importJsonButton")
        .addEventListener(
            "click",
            () =>
                $("importFileInput").click()
        );


    $("importFileInput")
        .addEventListener(
            "change",
            event => {

                const file =
                    event.target.files[0];

                importDatabase(file);

                event.target.value =
                    "";

            }
        );


    /* Delete everything */

    $("deleteAllDataButton")
        .addEventListener(
            "click",
            deleteAllData
        );


    /* Theme */

    $("themeSelect")
        .addEventListener(
            "change",
            async event => {

                state.settings.theme =
                    event.target.value;

                await saveSettings();

                applyTheme();

            }
        );


    /* Currency */

    $("currencySelect")
        .addEventListener(
            "change",
            async event => {

                state.settings.currency =
                    event.target.value;

                await saveSettings();

                renderEverything();

                showToast(
                    "Currency Updated",
                    "Financial amounts were updated.",
                    "✓"
                );

            }
        );


    /* Sample data */

    $("loadSampleButton")
        .addEventListener(
            "click",
            loadSampleData
        );


    /* Close modal by clicking outside */

    document
        .querySelectorAll(".modal-overlay")
        .forEach(modal => {

            modal.addEventListener(
                "click",
                event => {

                    if (
                        event.target ===
                        modal
                    ) {

                        modal.classList.add(
                            "hidden"
                        );

                    }

                }
            );

        });

}


/* =========================================================
   RENDER SETTINGS
========================================================= */

function renderSettings() {

    $("themeSelect").value =
        state.settings.theme || "light";


    $("currencySelect").value =
        state.settings.currency || "PHP";

}


/* =========================================================
   START APPLICATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializeApp
);