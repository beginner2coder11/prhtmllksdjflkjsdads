
/* =========================================================
   ASSISTANT NOTE
   OFFLINE APPLICATION ENGINE
========================================================= */


/* =========================================================
   STORAGE
========================================================= */

const STORAGE_KEY = "assistant_note_database_v1";

const SESSION_KEY = "assistant_note_session";


let db = {
    account: null,
    notes: [],
    schedules: [],
    passwords: [],
    contacts: []
};


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener("DOMContentLoaded", async () => {

    await initializeDatabase();

    if (sessionStorage.getItem(SESSION_KEY) === "true") {

        showApplication();

    } else {

        showLogin();

    }

    updateDashboard();

    renderNotes();
    renderSchedules();
    renderPasswords();
    renderContacts();

    checkReminders();

    setInterval(checkReminders, 30000);

});


/* =========================================================
   DATABASE
========================================================= */

async function initializeDatabase() {

    const saved =
        localStorage.getItem(STORAGE_KEY);

    if (saved) {

        try {

            db = JSON.parse(saved);

        } catch (error) {

            console.error(error);

            createDefaultDatabase();

        }

    } else {

        createDefaultDatabase();

    }

    if (!db.account) {

        await createDefaultAccount();

    }

}


function createDefaultDatabase() {

    db = {
        account: null,
        notes: [],
        schedules: [],
        passwords: [],
        contacts: []
    };

}


async function createDefaultAccount() {

    const username = "admin";
    const password = "admin123";

    db.account = {

        username: username,

        passwordHash:
            await hashPassword(password),

        createdAt:
            new Date().toISOString()

    };

    saveDatabase();

}


function saveDatabase() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(db)
    );

}


/* =========================================================
   SECURITY / HASH
========================================================= */

async function hashPassword(password) {

    const encoder =
        new TextEncoder();

    const data =
        encoder.encode(password);

    const hash =
        await crypto.subtle.digest(
            "SHA-256",
            data
        );

    return Array
        .from(new Uint8Array(hash))
        .map(
            byte =>
                byte.toString(16).padStart(2,"0")
        )
        .join("");

}


/* =========================================================
   LOGIN
========================================================= */

async function login() {

    const username =
        document
            .getElementById("loginUsername")
            .value
            .trim();

    const password =
        document
            .getElementById("loginPassword")
            .value;

    if (!username || !password) {

        toast("Enter username and password.");

        return;

    }

    const passwordHash =
        await hashPassword(password);

    if (
        username === db.account.username &&
        passwordHash === db.account.passwordHash
    ) {

        sessionStorage.setItem(
            SESSION_KEY,
            "true"
        );

        document
            .getElementById("loginPassword")
            .value = "";

        showApplication();

        toast("Login successful.");

    } else {

        toast("Invalid username or password.");

    }

}


/* =========================================================
   APPLICATION VISIBILITY
========================================================= */

function showLogin() {

    document
        .getElementById("loginScreen")
        .style.display = "flex";

    document
        .getElementById("app")
        .style.display = "none";

}


function showApplication() {

    document
        .getElementById("loginScreen")
        .style.display = "none";

    document
        .getElementById("app")
        .style.display = "block";

}


/* =========================================================
   LOCK
========================================================= */

function lockApp() {

    sessionStorage.removeItem(
        SESSION_KEY
    );

    showLogin();

    document
        .getElementById("loginUsername")
        .value = db.account.username;

    document
        .getElementById("loginPassword")
        .value = "";

}


/* =========================================================
   NAVIGATION
========================================================= */

function showPage(page, button) {

    document
        .querySelectorAll(".page")
        .forEach(element => {

            element.classList.remove("active");

        });

    document
        .getElementById(
            "page-" + page
        )
        .classList.add("active");


    document
        .querySelectorAll(".nav-btn")
        .forEach(element => {

            element.classList.remove("active");

        });


    if (button) {

        button.classList.add("active");

    } else {

        const nav =
            document.querySelector(
                `.nav-btn[data-page="${page}"]`
            );

        if (nav) {
            nav.classList.add("active");
        }

    }

    window.scrollTo(0,0);

}


/* =========================================================
   MODALS
========================================================= */

function openModal(id) {

    document
        .getElementById(id)
        .classList.add("show");

}


function closeModal(id) {

    document
        .getElementById(id)
        .classList.remove("show");

}


/* =========================================================
   NOTES
========================================================= */

function openNoteModal(id = null) {

    document
        .getElementById("noteId")
        .value = "";

    document
        .getElementById("noteTitle")
        .value = "";

    document
        .getElementById("noteCategory")
        .value = "Personal";

    document
        .getElementById("noteStatement")
        .value = "";


    if (id) {

        const note =
            db.notes.find(
                item => item.id === id
            );

        if (!note) return;

        document
            .getElementById("noteId")
            .value = note.id;

        document
            .getElementById("noteTitle")
            .value = note.title;

        document
            .getElementById("noteCategory")
            .value = note.category;

        document
            .getElementById("noteStatement")
            .value = note.statement;

    }

    openModal("noteModal");

}


function saveNote() {

    const id =
        document
            .getElementById("noteId")
            .value;

    const title =
        document
            .getElementById("noteTitle")
            .value
            .trim();

    const category =
        document
            .getElementById("noteCategory")
            .value;

    const statement =
        document
            .getElementById("noteStatement")
            .value
            .trim();


    if (!title) {

        toast("Enter a note title.");

        return;

    }

    if (!statement) {

        toast("Enter the note statement.");

        return;

    }


    if (id) {

        const note =
            db.notes.find(
                item => item.id === id
            );

        if (note) {

            note.title = title;
            note.category = category;
            note.statement = statement;
            note.updatedAt =
                new Date().toISOString();

        }

    } else {

        db.notes.unshift({

            id: createId(),

            title,
            category,
            statement,

            createdAt:
                new Date().toISOString(),

            updatedAt:
                new Date().toISOString()

        });

    }


    saveDatabase();

    closeModal("noteModal");

    renderNotes();

    updateDashboard();

    toast("Note saved.");

}


function renderNotes() {

    const container =
        document.getElementById(
            "notesList"
        );

    const search =
        (
            document.getElementById(
                "noteSearch"
            )?.value || ""
        )
        .toLowerCase()
        .trim();


    const notes =
        db.notes.filter(note => {

            if (!search) return true;

            return (
                note.title
                    .toLowerCase()
                    .includes(search)
                ||
                note.statement
                    .toLowerCase()
                    .includes(search)
                ||
                note.category
                    .toLowerCase()
                    .includes(search)
            );

        });


    if (!notes.length) {

        container.innerHTML = `
            <div class="card empty">
                <div class="empty-icon">📝</div>
                No notes found.
            </div>
        `;

        return;

    }


    container.innerHTML =
        notes.map(note => `

            <div class="card">

                <div class="button-row"
                     style="justify-content:space-between">

                    <div class="card-title">
                        ${escapeHTML(note.title)}
                    </div>

                    <span class="badge badge-blue">
                        ${escapeHTML(note.category)}
                    </span>

                </div>

                <div class="card-meta">
                    ${formatDate(note.updatedAt)}
                </div>

                <div class="card-body">
                    ${escapeHTML(note.statement)}
                </div>

                <div
                    class="button-row"
                    style="margin-top:13px">

                    <button
                        class="btn btn-small btn-secondary"
                        onclick="openNoteModal('${note.id}')">
                        Edit
                    </button>

                    <button
                        class="btn btn-small btn-light"
                        onclick="printNote('${note.id}')">
                        Print
                    </button>

                    <button
                        class="btn btn-small btn-danger"
                        onclick="deleteNote('${note.id}')">
                        Delete
                    </button>

                </div>

            </div>

        `).join("");

}


function deleteNote(id) {

    if (!confirm("Delete this note?")) return;

    db.notes =
        db.notes.filter(
            note => note.id !== id
        );

    saveDatabase();

    renderNotes();

    updateDashboard();

    toast("Note deleted.");

}


function printNote(id) {

    const note =
        db.notes.find(
            item => item.id === id
        );

    if (!note) return;

    const html = createReportHTML(
        "Assistant Note — Note Report",
        `
            <h2>${escapeHTML(note.title)}</h2>
            <p><strong>Category:</strong>
            ${escapeHTML(note.category)}</p>

            <p><strong>Date:</strong>
            ${formatDate(note.updatedAt)}</p>

            <hr>

            <p>${escapeHTML(note.statement)}</p>
        `
    );

    openPrintWindow(html);

}


/* =========================================================
   SCHEDULE
========================================================= */

function openScheduleModal(id = null) {

    document
        .getElementById("scheduleId")
        .value = "";

    document
        .getElementById("scheduleTitle")
        .value = "";

    document
        .getElementById("scheduleType")
        .value = "Activity";

    document
        .getElementById("scheduleDate")
        .value = "";

    document
        .getElementById("scheduleTime")
        .value = "";

    document
        .getElementById("scheduleReminder")
        .value = "0";

    document
        .getElementById("scheduleAlarm")
        .checked = true;

    document
        .getElementById("scheduleDetails")
        .value = "";


    if (id) {

        const item =
            db.schedules.find(
                schedule => schedule.id === id
            );

        if (!item) return;

        document
            .getElementById("scheduleId")
            .value = item.id;

        document
            .getElementById("scheduleTitle")
            .value = item.title;

        document
            .getElementById("scheduleType")
            .value = item.type;

        document
            .getElementById("scheduleDate")
            .value = item.date;

        document
            .getElementById("scheduleTime")
            .value = item.time;

        document
            .getElementById("scheduleReminder")
            .value = item.reminder;

        document
            .getElementById("scheduleAlarm")
            .checked = item.alarm;

        document
            .getElementById("scheduleDetails")
            .value = item.details;

    }

    openModal("scheduleModal");

}


function saveSchedule() {

    const id =
        document
            .getElementById("scheduleId")
            .value;

    const title =
        document
            .getElementById("scheduleTitle")
            .value
            .trim();

    const type =
        document
            .getElementById("scheduleType")
            .value;

    const date =
        document
            .getElementById("scheduleDate")
            .value;

    const time =
        document
            .getElementById("scheduleTime")
            .value;

    const reminder =
        Number(
            document
                .getElementById("scheduleReminder")
                .value
        );

    const alarm =
        document
            .getElementById("scheduleAlarm")
            .checked;

    const details =
        document
            .getElementById("scheduleDetails")
            .value
            .trim();


    if (!title) {

        toast("Enter schedule title.");

        return;

    }

    if (!date) {

        toast("Select a date.");

        return;

    }

    if (!time) {

        toast("Select a time.");

        return;

    }


    if (id) {

        const item =
            db.schedules.find(
                schedule => schedule.id === id
            );

        if (item) {

            item.title = title;
            item.type = type;
            item.date = date;
            item.time = time;
            item.reminder = reminder;
            item.alarm = alarm;
            item.details = details;

        }

    } else {

        db.schedules.push({

            id: createId(),

            title,
            type,
            date,
            time,
            reminder,
            alarm,
            details,

            completed: false,

            notified: false,

            createdAt:
                new Date().toISOString()

        });

    }


    saveDatabase();

    closeModal("scheduleModal");

    renderSchedules();

    renderUpcoming();

    updateDashboard();

    toast("Schedule saved.");

}


function getScheduleDateTime(item) {

    return new Date(
        `${item.date}T${item.time}:00`
    );

}


function renderSchedules() {

    const container =
        document.getElementById(
            "scheduleList"
        );

    const search =
        (
            document.getElementById(
                "scheduleSearch"
            )?.value || ""
        )
        .toLowerCase()
        .trim();


    const schedules =
        db.schedules
            .filter(item => {

                if (!search) return true;

                return (
                    item.title
                        .toLowerCase()
                        .includes(search)
                    ||
                    item.type
                        .toLowerCase()
                        .includes(search)
                    ||
                    item.details
                        .toLowerCase()
                        .includes(search)
                );

            })
            .sort(
                (a,b) =>
                    getScheduleDateTime(a)
                    -
                    getScheduleDateTime(b)
            );


    if (!schedules.length) {

        container.innerHTML = `
            <div class="card empty">
                <div class="empty-icon">📅</div>
                No schedules found.
            </div>
        `;

        return;

    }


    container.innerHTML =
        schedules.map(item => {

            const due =
                getScheduleDateTime(item);

            const past =
                due < new Date();

            return `

                <div class="card">

                    <div class="button-row"
                         style="justify-content:space-between">

                        <div class="card-title">
                            ${escapeHTML(item.title)}
                        </div>

                        <span class="badge ${
                            past
                            ? "badge-red"
                            : "badge-green"
                        }">
                            ${past ? "Past" : "Upcoming"}
                        </span>

                    </div>

                    <div class="card-meta">

                        ${escapeHTML(item.type)}
                        ·
                        ${formatDateTime(due)}

                    </div>

                    ${
                        item.details
                        ?
                        `<div class="card-body">
                            ${escapeHTML(item.details)}
                        </div>`
                        :
                        ""
                    }

                    <div
                        class="button-row"
                        style="margin-top:13px">

                        <button
                            class="btn btn-small btn-secondary"
                            onclick="openScheduleModal('${item.id}')">
                            Edit
                        </button>

                        <button
                            class="btn btn-small btn-light"
                            onclick="completeSchedule('${item.id}')">
                            ${item.completed ? "Undo" : "Done"}
                        </button>

                        <button
                            class="btn btn-small btn-danger"
                            onclick="deleteSchedule('${item.id}')">
                            Delete
                        </button>

                    </div>

                </div>

            `;

        }).join("");

}


function completeSchedule(id) {

    const item =
        db.schedules.find(
            schedule => schedule.id === id
        );

    if (!item) return;

    item.completed =
        !item.completed;

    saveDatabase();

    renderSchedules();

    renderUpcoming();

    toast(
        item.completed
        ? "Schedule completed."
        : "Schedule reopened."
    );

}


function deleteSchedule(id) {

    if (!confirm("Delete this schedule?")) return;

    db.schedules =
        db.schedules.filter(
            item => item.id !== id
        );

    saveDatabase();

    renderSchedules();

    renderUpcoming();

    updateDashboard();

    toast("Schedule deleted.");

}


function renderUpcoming() {

    const container =
        document.getElementById(
            "upcomingSchedules"
        );

    if (!container) return;

    const now =
        new Date();

    const items =
        db.schedules
            .filter(
                item =>
                    !item.completed &&
                    getScheduleDateTime(item) >= now
            )
            .sort(
                (a,b) =>
                    getScheduleDateTime(a)
                    -
                    getScheduleDateTime(b)
            )
            .slice(0,4);


    if (!items.length) {

        container.innerHTML = `
            <div class="empty">
                No upcoming schedules.
            </div>
        `;

        return;

    }


    container.innerHTML =
        items.map(item => `

            <div
                style="
                padding:12px 0;
                border-bottom:1px solid #edf0f4">

                <strong>
                    ${escapeHTML(item.title)}
                </strong>

                <div class="card-meta">

                    ${escapeHTML(item.type)}
                    ·
                    ${formatDateTime(
                        getScheduleDateTime(item)
                    )}

                </div>

            </div>

        `).join("");

}


/* =========================================================
   REMINDERS
========================================================= */

function checkReminders() {

    const now =
        new Date();

    let changed = false;


    db.schedules.forEach(item => {

        if (
            !item.alarm ||
            item.completed ||
            item.notified
        ) {
            return;
        }


        const scheduleTime =
            getScheduleDateTime(item);

        const reminderTime =
            new Date(
                scheduleTime.getTime()
                -
                Number(item.reminder) * 60000
            );


        if (
            now >= reminderTime &&
            now < new Date(
                scheduleTime.getTime() + 60000
            )
        ) {

            notifySchedule(item);

            item.notified = true;

            changed = true;

        }

    });


    if (changed) {
        saveDatabase();
        renderSchedules();
        renderUpcoming();
    }

}


function notifySchedule(item) {

    const message =
        `Reminder: ${item.title}`;

    toast(message);


    if (
        "Notification" in window &&
        Notification.permission === "granted"
    ) {

        try {

            new Notification(
                "Assistant Note",
                {
                    body: message
                }
            );

        } catch (error) {

            console.log(error);

        }

    }

}


async function requestNotifications() {

    if (!("Notification" in window)) {

        toast(
            "Notifications are not supported by this Android container."
        );

        return;

    }


    try {

        const result =
            await Notification.requestPermission();

        toast(
            result === "granted"
            ? "Notifications enabled."
            : "Notification permission was not granted."
        );

    } catch (error) {

        toast("Unable to request notification permission.");

    }

}


/* =========================================================
   PASSWORD MANAGER
========================================================= */

function openPasswordModal(id = null) {

    document
        .getElementById("passwordId")
        .value = "";

    document
        .getElementById("passwordService")
        .value = "";

    document
        .getElementById("passwordUsername")
        .value = "";

    document
        .getElementById("passwordValue")
        .value = "";

    document
        .getElementById("passwordNote")
        .value = "";


    if (id) {

        const item =
            db.passwords.find(
                password => password.id === id
            );

        if (!item) return;

        document
            .getElementById("passwordId")
            .value = item.id;

        document
            .getElementById("passwordService")
            .value = item.service;

        document
            .getElementById("passwordUsername")
            .value = item.username;

        document
            .getElementById("passwordValue")
            .value = item.password;

        document
            .getElementById("passwordNote")
            .value = item.note;

    }


    openModal("passwordModal");

}


function savePassword() {

    const id =
        document
            .getElementById("passwordId")
            .value;

    const service =
        document
            .getElementById("passwordService")
            .value
            .trim();

    const username =
        document
            .getElementById("passwordUsername")
            .value
            .trim();

    const password =
        document
            .getElementById("passwordValue")
            .value;

    const note =
        document
            .getElementById("passwordNote")
            .value
            .trim();


    if (!service) {

        toast("Enter account or website.");

        return;

    }

    if (!username) {

        toast("Enter username or email.");

        return;

    }

    if (!password) {

        toast("Enter password.");

        return;

    }


    if (id) {

        const item =
            db.passwords.find(
                passwordItem =>
                    passwordItem.id === id
            );

        if (item) {

            item.service = service;
            item.username = username;
            item.password = password;
            item.note = note;

        }

    } else {

        db.passwords.unshift({

            id: createId(),

            service,
            username,
            password,
            note,

            createdAt:
                new Date().toISOString()

        });

    }


    saveDatabase();

    closeModal("passwordModal");

    renderPasswords();

    updateDashboard();

    toast("Password entry saved.");

}


function renderPasswords() {

    const container =
        document.getElementById(
            "passwordList"
        );

    const search =
        (
            document.getElementById(
                "passwordSearch"
            )?.value || ""
        )
        .toLowerCase()
        .trim();


    const items =
        db.passwords.filter(item => {

            if (!search) return true;

            return (
                item.service
                    .toLowerCase()
                    .includes(search)
                ||
                item.username
                    .toLowerCase()
                    .includes(search)
            );

        });


    if (!items.length) {

        container.innerHTML = `
            <div class="card empty">
                <div class="empty-icon">🔑</div>
                No password entries found.
            </div>
        `;

        return;

    }


    container.innerHTML =
        items.map(item => `

            <div class="card">

                <div class="card-title">
                    🔑 ${escapeHTML(item.service)}
                </div>

                <div class="card-meta">
                    Username:
                    ${escapeHTML(item.username)}
                </div>

                <div
                    class="password-wrap"
                    style="margin-top:12px">

                    <input
                        id="storedPass_${item.id}"
                        type="password"
                        value="${escapeAttribute(item.password)}"
                        readonly>

                    <button
                        class="password-eye"
                        onclick="toggleStoredPassword('${item.id}',this)">
                        👁
                    </button>

                </div>

                ${
                    item.note
                    ?
                    `<div class="card-body">
                        ${escapeHTML(item.note)}
                    </div>`
                    :
                    ""
                }

                <div
                    class="button-row"
                    style="margin-top:13px">

                    <button
                        class="btn btn-small btn-secondary"
                        onclick="copyText('${escapeAttribute(item.username)}')">
                        Copy User
                    </button>

                    <button
                        class="btn btn-small btn-secondary"
                        onclick="copyText('${escapeAttribute(item.password)}')">
                        Copy Password
                    </button>

                    <button
                        class="btn btn-small btn-light"
                        onclick="openPasswordModal('${item.id}')">
                        Edit
                    </button>

                    <button
                        class="btn btn-small btn-danger"
                        onclick="deletePassword('${item.id}')">
                        Delete
                    </button>

                </div>

            </div>

        `).join("");

}


function toggleStoredPassword(id, button) {

    const input =
        document.getElementById(
            "storedPass_" + id
        );

    if (!input) return;

    if (input.type === "password") {

        input.type = "text";

        button.textContent = "🙈";

    } else {

        input.type = "password";

        button.textContent = "👁";

    }

}


function deletePassword(id) {

    if (!confirm("Delete this password entry?")) return;

    db.passwords =
        db.passwords.filter(
            item => item.id !== id
        );

    saveDatabase();

    renderPasswords();

    updateDashboard();

    toast("Password entry deleted.");

}


/* =========================================================
   CONTACTS
========================================================= */

function openContactModal(id = null) {

    document
        .getElementById("contactId")
        .value = "";

    document
        .getElementById("contactName")
        .value = "";

    document
        .getElementById("contactPhone")
        .value = "";

    document
        .getElementById("contactEmail")
        .value = "";

    document
        .getElementById("contactNotes")
        .value = "";


    if (id) {

        const item =
            db.contacts.find(
                contact => contact.id === id
            );

        if (!item) return;

        document
            .getElementById("contactId")
            .value = item.id;

        document
            .getElementById("contactName")
            .value = item.name;

        document
            .getElementById("contactPhone")
            .value = item.phone;

        document
            .getElementById("contactEmail")
            .value = item.email;

        document
            .getElementById("contactNotes")
            .value = item.notes;

    }

    openModal("contactModal");

}


function saveContact() {

    const id =
        document
            .getElementById("contactId")
            .value;

    const name =
        document
            .getElementById("contactName")
            .value
            .trim();

    const phone =
        document
            .getElementById("contactPhone")
            .value
            .trim();

    const email =
        document
            .getElementById("contactEmail")
            .value
            .trim();

    const notes =
        document
            .getElementById("contactNotes")
            .value
            .trim();


    if (!name) {

        toast("Enter contact name.");

        return;

    }


    if (id) {

        const item =
            db.contacts.find(
                contact => contact.id === id
            );

        if (item) {

            item.name = name;
            item.phone = phone;
            item.email = email;
            item.notes = notes;

        }

    } else {

        db.contacts.unshift({

            id: createId(),

            name,
            phone,
            email,
            notes,

            createdAt:
                new Date().toISOString()

        });

    }


    saveDatabase();

    closeModal("contactModal");

    renderContacts();

    updateDashboard();

    toast("Contact saved.");

}


function renderContacts() {

    const container =
        document.getElementById(
            "contactsList"
        );

    const search =
        (
            document.getElementById(
                "contactSearch"
            )?.value || ""
        )
        .toLowerCase()
        .trim();


    const contacts =
        db.contacts.filter(item => {

            if (!search) return true;

            return (
                item.name
                    .toLowerCase()
                    .includes(search)
                ||
                item.phone
                    .toLowerCase()
                    .includes(search)
                ||
                item.email
                    .toLowerCase()
                    .includes(search)
            );

        });


    if (!contacts.length) {

        container.innerHTML = `
            <div class="card empty">
                <div class="empty-icon">👥</div>
                No contacts found.
            </div>
        `;

        return;

    }


    container.innerHTML =
        contacts.map(item => `

            <div class="card">

                <div class="contact-row">

                    <div class="contact-avatar">
                        ${getInitials(item.name)}
                    </div>

                    <div class="contact-info">

                        <div class="contact-name">
                            ${escapeHTML(item.name)}
                        </div>

                        <div class="contact-number">
                            ${escapeHTML(item.phone || "No phone number")}
                        </div>

                        ${
                            item.email
                            ?
                            `<div class="contact-number">
                                ${escapeHTML(item.email)}
                            </div>`
                            :
                            ""
                        }

                    </div>

                </div>

                ${
                    item.notes
                    ?
                    `<div class="card-body">
                        ${escapeHTML(item.notes)}
                    </div>`
                    :
                    ""
                }

                <div
                    class="button-row"
                    style="margin-top:13px">

                    <button
                        class="btn btn-small btn-secondary"
                        onclick="callContact('${escapeAttribute(item.phone)}')">
                        📞 Call
                    </button>

                    <button
                        class="btn btn-small btn-light"
                        onclick="openContactModal('${item.id}')">
                        Edit
                    </button>

                    <button
                        class="btn btn-small btn-danger"
                        onclick="deleteContact('${item.id}')">
                        Delete
                    </button>

                </div>

            </div>

        `).join("");

}


function callContact(number) {

    if (!number) {

        toast("No phone number available.");

        return;

    }

    window.location.href =
        "tel:" + number;

}


function deleteContact(id) {

    if (!confirm("Delete this contact?")) return;

    db.contacts =
        db.contacts.filter(
            item => item.id !== id
        );

    saveDatabase();

    renderContacts();

    updateDashboard();

    toast("Contact deleted.");

}


/* =========================================================
   CONTACT IMPORT
========================================================= */

function importContacts(input) {

    const file =
        input.files[0];

    if (!file) return;


    const reader =
        new FileReader();


    reader.onload = function(event) {

        const text =
            event.target.result;

        const lower =
            file.name.toLowerCase();


        try {

            if (
                lower.endsWith(".vcf") ||
                text.includes("BEGIN:VCARD")
            ) {

                importVCard(text);

            } else {

                importCSVContacts(text);

            }

        } catch (error) {

            console.error(error);

            toast("Unable to import contacts.");

        }

        input.value = "";

    };


    reader.readAsText(file);

}


function importVCard(text) {

    const cards =
        text.split(
            /BEGIN:VCARD/i
        );

    let count = 0;


    cards.forEach(block => {

        if (!block.trim()) return;

        const fn =
            extractVCard(block,"FN");

        const tel =
            extractVCard(block,"TEL");

        const email =
            extractVCard(block,"EMAIL");

        const note =
            extractVCard(block,"NOTE");


        if (!fn && !tel) return;


        db.contacts.push({

            id: createId(),

            name: fn || "Imported Contact",

            phone: tel || "",

            email: email || "",

            notes: note || "",

            createdAt:
                new Date().toISOString()

        });


        count++;

    });


    saveDatabase();

    renderContacts();

    updateDashboard();

    toast(
        count + " contact(s) imported."
    );

}


function extractVCard(block, field) {

    const regex =
        new RegExp(
            "^" +
            field +
            "(?:;[^:]*)?:(.*)$",
            "mi"
        );

    const match =
        block.match(regex);

    return match
        ? match[1].trim()
        : "";

}


function importCSVContacts(text) {

    const lines =
        text.split(/\r?\n/);

    let count = 0;


    lines.forEach((line,index) => {

        if (!line.trim()) return;

        if (
            index === 0 &&
            line.toLowerCase().includes("name")
        ) {
            return;
        }


        const columns =
            parseCSVLine(line);


        const name =
            columns[0] || "";

        const phone =
            columns[1] || "";

        const email =
            columns[2] || "";

        const notes =
            columns[3] || "";


        if (!name && !phone) return;


        db.contacts.push({

            id: createId(),

            name,

            phone,

            email,

            notes,

            createdAt:
                new Date().toISOString()

        });


        count++;

    });


    saveDatabase();

    renderContacts();

    updateDashboard();

    toast(
        count + " contact(s) imported."
    );

}


function parseCSVLine(line) {

    const result = [];

    let current = "";

    let insideQuotes = false;


    for (
        let i = 0;
        i < line.length;
        i++
    ) {

        const char =
            line[i];


        if (char === '"') {

            if (
                insideQuotes &&
                line[i + 1] === '"'
            ) {

                current += '"';

                i++;

            } else {

                insideQuotes =
                    !insideQuotes;

            }

        } else if (
            char === "," &&
            !insideQuotes
        ) {

            result.push(
                current.trim()
            );

            current = "";

        } else {

            current += char;

        }

    }


    result.push(
        current.trim()
    );

    return result;

}


/* =========================================================
   CONTACT EXPORT
========================================================= */

function exportContactsCSV() {

    const rows = [

        [
            "Name",
            "Phone",
            "Email",
            "Notes"
        ]

    ];


    db.contacts.forEach(item => {

        rows.push([

            item.name,
            item.phone,
            item.email,
            item.notes

        ]);

    });


    const csv =
        rows.map(
            row =>
                row.map(csvEscape).join(",")
        ).join("\n");


    downloadFile(
        csv,
        "assistant-note-contacts.csv",
        "text/csv"
    );

}


function exportContactsVCard() {

    let output = "";


    db.contacts.forEach(item => {

        output +=
`BEGIN:VCARD
VERSION:3.0
FN:${vCardEscape(item.name)}
TEL:${vCardEscape(item.phone)}
EMAIL:${vCardEscape(item.email)}
NOTE:${vCardEscape(item.notes)}
END:VCARD
`;

    });


    downloadFile(
        output,
        "assistant-note-contacts.vcf",
        "text/vcard"
    );

}


/* =========================================================
   GLOBAL SEARCH
========================================================= */

function globalSearch(value) {

    const container =
        document.getElementById(
            "globalResults"
        );

    const search =
        value.toLowerCase().trim();


    if (!search) {

        container.classList.add(
            "hidden"
        );

        container.innerHTML = "";

        return;

    }


    const notes =
        db.notes.filter(item =>
            item.title.toLowerCase().includes(search) ||
            item.statement.toLowerCase().includes(search)
        );


    const schedules =
        db.schedules.filter(item =>
            item.title.toLowerCase().includes(search) ||
            item.type.toLowerCase().includes(search) ||
            item.details.toLowerCase().includes(search)
        );


    const passwords =
        db.passwords.filter(item =>
            item.service.toLowerCase().includes(search) ||
            item.username.toLowerCase().includes(search)
        );


    const contacts =
        db.contacts.filter(item =>
            item.name.toLowerCase().includes(search) ||
            item.phone.toLowerCase().includes(search) ||
            item.email.toLowerCase().includes(search)
        );


    const total =
        notes.length +
        schedules.length +
        passwords.length +
        contacts.length;


    container.classList.remove(
        "hidden"
    );


    if (!total) {

        container.innerHTML = `
            <div class="card empty">
                No matching information found.
            </div>
        `;

        return;

    }


    let html = "";


    if (notes.length) {

        html += `
            <div class="card">
                <div class="card-title">
                    📝 Notes (${notes.length})
                </div>
        `;

        notes.slice(0,5).forEach(item => {

            html += `
                <div
                    style="
                    padding:11px 0;
                    border-bottom:1px solid #edf0f4"
                    onclick="openNoteModal('${item.id}')">

                    <strong>
                        ${escapeHTML(item.title)}
                    </strong>

                    <div class="card-meta">
                        ${escapeHTML(
                            item.statement.substring(0,100)
                        )}
                    </div>

                </div>
            `;

        });

        html += `</div>`;

    }


    if (schedules.length) {

        html += `
            <div class="card">
                <div class="card-title">
                    📅 Schedules (${schedules.length})
                </div>
        `;

        schedules.slice(0,5).forEach(item => {

            html += `
                <div
                    style="
                    padding:11px 0;
                    border-bottom:1px solid #edf0f4"
                    onclick="openScheduleModal('${item.id}')">

                    <strong>
                        ${escapeHTML(item.title)}
                    </strong>

                    <div class="card-meta">
                        ${escapeHTML(item.type)}
                    </div>

                </div>
            `;

        });

        html += `</div>`;

    }


    if (passwords.length) {

        html += `
            <div class="card">
                <div class="card-title">
                    🔑 Password Accounts (${passwords.length})
                </div>
        `;

        passwords.slice(0,5).forEach(item => {

            html += `
                <div
                    style="
                    padding:11px 0;
                    border-bottom:1px solid #edf0f4"
                    onclick="openPasswordModal('${item.id}')">

                    <strong>
                        ${escapeHTML(item.service)}
                    </strong>

                    <div class="card-meta">
                        ${escapeHTML(item.username)}
                    </div>

                </div>
            `;

        });

        html += `</div>`;

    }


    if (contacts.length) {

        html += `
            <div class="card">
                <div class="card-title">
                    👥 Contacts (${contacts.length})
                </div>
        `;

        contacts.slice(0,5).forEach(item => {

            html += `
                <div
                    style="
                    padding:11px 0;
                    border-bottom:1px solid #edf0f4"
                    onclick="openContactModal('${item.id}')">

                    <strong>
                        ${escapeHTML(item.name)}
                    </strong>

                    <div class="card-meta">
                        ${escapeHTML(item.phone)}
                    </div>

                </div>
            `;

        });

        html += `</div>`;

    }


    container.innerHTML = html;

}


/* =========================================================
   SECURITY SETTINGS
========================================================= */

function openSecurityModal() {

    document
        .getElementById("currentPassword")
        .value = "";

    document
        .getElementById("newUsername")
        .value =
            db.account.username;

    document
        .getElementById("newPassword")
        .value = "";

    document
        .getElementById("confirmPassword")
        .value = "";

    openModal("securityModal");

}


async function changeSecurity() {

    const current =
        document
            .getElementById("currentPassword")
            .value;

    const username =
        document
            .getElementById("newUsername")
            .value
            .trim();

    const password =
        document
            .getElementById("newPassword")
            .value;

    const confirm =
        document
            .getElementById("confirmPassword")
            .value;


    if (!current) {

        toast("Enter current password.");

        return;

    }


    const currentHash =
        await hashPassword(current);


    if (
        currentHash !==
        db.account.passwordHash
    ) {

        toast("Current password is incorrect.");

        return;

    }


    if (!username) {

        toast("Username cannot be empty.");

        return;

    }


    if (password) {

        if (password.length < 6) {

            toast(
                "New password must be at least 6 characters."
            );

            return;

        }


        if (password !== confirm) {

            toast(
                "New passwords do not match."
            );

            return;

        }

        db.account.passwordHash =
            await hashPassword(password);

    }


    db.account.username =
        username;


    saveDatabase();

    closeModal("securityModal");

    toast(
        "Security settings updated."
    );

}


/* =========================================================
   BACKUP
========================================================= */

function exportBackup() {

    const backup = {

        application:
            "Assistant Note",

        version:
            "1.0.0",

        exportedAt:
            new Date().toISOString(),

        data: {

            notes:
                db.notes,

            schedules:
                db.schedules,

            passwords:
                db.passwords,

            contacts:
                db.contacts

        }

    };


    const json =
        JSON.stringify(
            backup,
            null,
            2
        );


    downloadFile(
        json,
        "assistant-note-backup.json",
        "application/json"
    );


    toast("Backup exported.");

}


function importBackup(input) {

    const file =
        input.files[0];

    if (!file) return;


    const reader =
        new FileReader();


    reader.onload = function(event) {

        try {

            const backup =
                JSON.parse(
                    event.target.result
                );


            if (
                !backup.data ||
                !Array.isArray(
                    backup.data.notes
                )
            ) {

                throw new Error(
                    "Invalid backup"
                );

            }


            if (
                !confirm(
                    "Restore backup? Existing notes, schedules, passwords and contacts will be replaced."
                )
            ) {

                input.value = "";

                return;

            }


            db.notes =
                backup.data.notes || [];

            db.schedules =
                backup.data.schedules || [];

            db.passwords =
                backup.data.passwords || [];

            db.contacts =
                backup.data.contacts || [];


            saveDatabase();

            renderNotes();
            renderSchedules();
            renderPasswords();
            renderContacts();
            renderUpcoming();
            updateDashboard();


            toast(
                "Backup restored successfully."
            );

        } catch (error) {

            console.error(error);

            toast(
                "Invalid Assistant Note backup."
            );

        }


        input.value = "";

    };


    reader.readAsText(file);

}


/* =========================================================
   CLEAR DATABASE
========================================================= */

async function clearDatabase() {

    const answer =
        prompt(
            "Type DELETE to permanently clear all notes, schedules, passwords and contacts."
        );


    if (answer !== "DELETE") {

        toast("Database was not cleared.");

        return;

    }


    db.notes = [];
    db.schedules = [];
    db.passwords = [];
    db.contacts = [];


    saveDatabase();

    renderNotes();
    renderSchedules();
    renderPasswords();
    renderContacts();
    renderUpcoming();
    updateDashboard();


    toast(
        "Application data cleared."
    );

}


/* =========================================================
   REPORT
========================================================= */

function printCurrentPage() {

    const active =
        document.querySelector(
            ".page.active"
        );

    if (!active) return;


    const title =
        active
            .querySelector(".page-title")
            ?.textContent ||
        "Assistant Note Report";


    const content =
        active.innerHTML;


    openPrintWindow(
        createReportHTML(
            "Assistant Note — " + title,
            content
        )
    );

}


function createReportHTML(title, content) {

    return `
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>${escapeHTML(title)}</title>

<style>

body {
    font-family: Arial, sans-serif;
    padding: 30px;
    color: #111827;
}

h1 {
    margin-bottom: 25px;
}

.card {
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 12px;
}

button,
input,
textarea,
select {
    display: none;
}

</style>

</head>

<body>

<h1>
${escapeHTML(title)}
</h1>

${content}

</body>

</html>
`;

}


function openPrintWindow(html) {

    const printWindow =
        window.open(
            "",
            "_blank"
        );


    if (!printWindow) {

        toast(
            "Allow pop-ups to print the report."
        );

        return;

    }


    printWindow.document.open();

    printWindow.document.write(
        html
    );

    printWindow.document.close();


    setTimeout(() => {

        printWindow.focus();

        printWindow.print();

    },500);

}


/* =========================================================
   DASHBOARD
========================================================= */

function updateDashboard() {

    const notes =
        document.getElementById(
            "statNotes"
        );

    const schedules =
        document.getElementById(
            "statSchedules"
        );

    const passwords =
        document.getElementById(
            "statPasswords"
        );

    const contacts =
        document.getElementById(
            "statContacts"
        );


    if (notes)
        notes.textContent =
            db.notes.length;

    if (schedules)
        schedules.textContent =
            db.schedules.length;

    if (passwords)
        passwords.textContent =
            db.passwords.length;

    if (contacts)
        contacts.textContent =
            db.contacts.length;

}


/* =========================================================
   UTILITIES
========================================================= */

function createId() {

    return (
        Date.now().toString(36)
        +
        Math.random()
            .toString(36)
            .substring(2,9)
    );

}


function togglePassword(id, button) {

    const input =
        document.getElementById(id);

    if (!input) return;


    if (input.type === "password") {

        input.type = "text";

        button.textContent = "🙈";

    } else {

        input.type = "password";

        button.textContent = "👁";

    }

}


async function copyText(text) {

    try {

        await navigator.clipboard.writeText(
            text
        );

        toast("Copied.");

    } catch {

        toast(
            "Copy is not available in this container."
        );

    }

}


function formatDate(dateString) {

    const date =
        new Date(dateString);

    if (Number.isNaN(date.getTime()))
        return dateString;


    return date.toLocaleDateString(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "numeric"
        }
    );

}


function formatDateTime(date) {

    return date.toLocaleString(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit"
        }
    );

}


function getInitials(name) {

    return name
        .split(/\s+/)
        .filter(Boolean)
        .slice(0,2)
        .map(
            word =>
                word
                    .charAt(0)
                    .toUpperCase()
        )
        .join("");

}


function escapeHTML(value) {

    return String(value ?? "")
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


function escapeAttribute(value) {

    return String(value ?? "")
        .replace(
            /\\/g,
            "\\\\"
        )
        .replace(
            /'/g,
            "\\'"
        )
        .replace(
            /"/g,
            "&quot;"
        );

}


function csvEscape(value) {

    return `"${String(value ?? "")
        .replace(/"/g,'""')}"`;

}


function vCardEscape(value) {

    return String(value ?? "")
        .replace(/\\/g,"\\\\")
        .replace(/\n/g,"\\n")
        .replace(/;/g,"\\;")
        .replace(/,/g,"\\,");

}


function downloadFile(
    content,
    filename,
    mime
) {

    const blob =
        new Blob(
            [content],
            {type:mime}
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement("a");


    link.href = url;

    link.download =
        filename;

    document.body.appendChild(
        link
    );

    link.click();

    link.remove();


    setTimeout(
        () =>
            URL.revokeObjectURL(url),
        1000
    );

}


function toast(message) {

    const element =
        document.getElementById(
            "toast"
        );


    element.textContent =
        message;

    element.classList.add(
        "show"
    );


    clearTimeout(
        window.__toastTimer
    );


    window.__toastTimer =
        setTimeout(() => {

            element.classList.remove(
                "show"
            );

        },2500);

}


/* =========================================================
   INITIAL DEFAULT USER
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Enter" &&
            document.activeElement &&
            (
                document.activeElement.id ===
                "loginUsername"
                ||
                document.activeElement.id ===
                "loginPassword"
            )
        ) {

            login();

        }

    }
);

